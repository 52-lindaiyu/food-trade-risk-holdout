# Food-trade risk models: code and minimal inputs

Computational code for **A held-out test of behavioural risk models of food-trade rewiring**, by Yi Jiang, Feng Han, Shuhao Chen, Hao Zheng, Li Cao and Chengyi Tu.

This package implements the paper's **corrected analysis**: behavioural portfolio choice (BR), its risk-free ablation (BR0), persistence, dynamic gravity, a temporal network model and graph neural networks; forecast evaluation; joint Laplace identification; synthetic recovery; and parameter perturbations. It includes the corrected robustness specifications. The historical sealed analysis and its process records are outside this release.

## Files

```text
run_reproduction.py               stage entry point
code/models.py                    models, fixed-point solver, gradients and Hessian
code/run.py                       selection, fitting, prediction and simulation
code/evaluate_v2.py               losses, bootstrap intervals and decision rules
code/analyse_identification.py    identification and recovery summaries
code/03_risk_landscape.py         anomalies and reference-covariance routines
config/config_v2.json             selected settings and computation budgets
data/arrays/*.npz                 52 direct model inputs (13 per commodity)
data/teleconnections_annual.csv   five seasonal climate factors
requirements.txt
LICENSE
```

## Environment and installation

The original computation environment was Linux, Python **3.11.10**, NumPy 1.26.3, SciPy 1.15.3, pandas 2.1.4 and PyTorch 2.0.1 on CPU. Use Python 3.11 with the supplied pins; the pins are not intended for Python 3.13. No GPU is required. The driver also supports Windows workers using multiprocessing `spawn`.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## Run

Run commands from this directory. The following prints the complete computation plan without fitting anything:

```bash
python run_reproduction.py --from dev --to analyse --workers 1 --dry-run
```

To use the supplied selected hyperparameters and compute the corrected fits, forecasts and summaries:

```bash
python run_reproduction.py --from fit --to analyse --workers 1
```

To repeat development selection as well:

```bash
python run_reproduction.py --from dev --to analyse --workers 1
```

The stages are `dev`, `select`, `fit`, `post`, `evaluate`, and `analyse`. `post` runs prediction, revised-solver diagnostics, joint Laplace calculations, parameter perturbations and synthetic recovery. Use `--from STAGE --to STAGE` to run a single stage. Dependencies must already have been produced: `select` needs `dev`, `post` needs `fit`, and the final summaries need `post`. Running without arguments displays help. These are full research computations and can take hours or longer on a CPU.

The supplied arrays already contain the reference covariances. To independently recompute these with the original covariance algorithm:

```bash
python run_reproduction.py --from risk --to risk
```

This optional computation writes covariances under `out/risk/`; it does not overwrite the supplied inputs or alter which inputs fitting uses.

## Inputs and parameters

The `.npz` files are **prepared numerical inputs, not fitted results**. They contain trade quantities `Q`, supplier unit values `UV`, total exports `TOT`, yield anomalies `A`, standardised shocks `Z`, policy indicators `POL`, reference covariances `SIG`, distances `D`, contiguity `CT`, language `CL`, country and supplier identifiers, region/income groups and year indexes. They are read with `allow_pickle=False` by the core model. Quantities are in tonnes, distances in kilometres, and the time step is one calendar year. The year axis is 1986-2024; anomaly/policy histories start in 1961.

Input provenance follows the paper: FAOSTAT Detailed Trade Matrix (wheat 15, maize 56, milled rice 30, soybeans 236); FAOSTAT production/yields (paddy rice 27 for yields); CEPII GeoDist; World Bank region/income classifications; and audited export-restriction episodes coded into `POL`. Climate factors are Nino 3.4 DJF/JAS and DMI SON/current and lagged from KNMI Climate Explorer, and NAO DJFM from the Climatic Research Unit. Sources: [FAOSTAT](https://www.fao.org/faostat/), [CEPII](https://www.cepii.fr/), [World Bank API](https://api.worldbank.org/), [KNMI Climate Explorer](https://climexp.knmi.nl/), and [CRU NAO](https://crudata.uea.ac.uk/cru/data/nao/).

Each commodity has `dev`, `pre`, `full`, and pre/full pairs for `s01`, `s09`, `cent`, `sevdur` and `legal`. Development inputs use static preprocessing through 2005; final inputs use 2013. `pre` and `dev` withhold post-2013 trade quantities; `full` supplies evaluation observations and rolling lags. Separate inputs preserve those boundaries and the paper's restriction-risk variants. Raw bulk data and extraction from original sources are outside this package; no network access or external local files are needed to run the supplied calculations.

The supplier covariance uses a 25-year window, ridge loading penalty 1 and policy-loss variance 0.04 (variants 0.01, 0.09, centred variance, severity/duration, and blockade removal). Memory is a normalised 30-year history, the shortfall cap is 3, and the lag-share offset is 0.005. BR is fitted by MAP with hierarchical priors, 2,500 Adam steps (learning rate 0.05, cosine decay) and up to 300 L-BFGS iterations. Newton tolerance is `1e-11`, with at most 100 iterations and 30 backtracking attempts. Importer starting coordinates are `(log gamma, delta, logit phi, logit omega) = (0, 0, 0, -2)`; pair effects start at zero. Other initial values and priors are explicit in `BRModel`.

Development trains on 1988-2005 and validates on 2006-2013; final fitting uses 1988-2013 and evaluation 2014-2024. Confirmatory windows are W1 (2014-2016), W2 (2020-2021), W3 (2022-2023), and tranquil T (2017-2019); 2024 is exploratory. Forecasts use information through the previous year, with a two-year-lag sensitivity. Parameters are not refitted in evaluation years.

The selected settings are preserved in `config/config_v2.json`: GNN widths/epochs are 32/55, 64/31, 64/42 and 64/27 for wheat, maize, rice and soybeans, with weight decay `1e-3` and five seeds (0-4). BR/BR0 prior selections and GNN variants are also preserved. Registered intervals use 2,000 importer-commodity bootstrap resamples; synthetic recovery uses 20 panels per commodity, half with starting-value jitter SD 0.5; parameter perturbations use 200 joint Laplace draws. Simulation seeds are `1000 + replicate`; jitter seeds are replicate indexes; Laplace draws use seed 11. Evaluation seeds and all stopping rules are explicit in the source. The primary loss is KL with forecast floor `1e-4`; Hellinger is secondary. Advantage is comparator loss minus BR loss.

## Outputs and limitations

Running the code creates fitted parameters, forecasts, solver diagnostics, Hessian/Laplace summaries and simulated recovery estimates under `out/`, followed by numeric CSV/JSON tables under `results/v2/`. No figures are generated. The original scripts reuse existing output files, so start with a fresh output directory when changing settings. Do not mix reduced exploratory runs with a full analysis.

This release was checked for syntax, imports, input completeness, covariance reconstruction and reduced numerical execution, including comparison against the original corrected code. The check environment was Windows, Python 3.13.3, NumPy 2.2.6, SciPy 1.17.1, pandas 3.0.5 and PyTorch 2.13.0+cpu. The original pinned environment was not reinstalled, and the full fitting/2,000-resample/80-panel analysis was not rerun during packaging. These checks establish executability of the exercised paths, not independent numerical reproduction of every published result. Solver convergence and the wheat Hessian's flat direction require the interpretation given in the paper.

Excluded: generated results and trained weights; images, plotting and typesetting code; manuscripts and submission/reviewer material; process logs, sealing/hash-gate records and historical v1 code; original bulk data, redundant raw inputs, caches, temporary files and development/test scripts. The historical-v1 part of the original solver audit was removed; the corrected numerical model, parameter values, selection rules and random seeds were preserved. File loading now uses ordinary module imports, failures propagate to the caller, and the entry point checks that required inputs and fitted files exist. The configuration omits only precomputed development-loss values. Dependencies used solely for plotting, spreadsheets or downloading data were removed. These packaging changes do not change successful corrected calculations.

## Contact, citation and license

Correspondence: Chengyi Tu, **chengyitu1986@gmail.com** (the corresponding-author contact in the manuscript).

Please cite: Jiang, Y., Han, F., Chen, S., Zheng, H., Cao, L. & Tu, C. *A held-out test of behavioural risk models of food-trade rewiring*. Manuscript supplied with this code. Publication details and a DOI were not provided in the source package; cite the published version when available. For a deposited code release, cite its archived version and DOI as well.

Code: MIT, retaining the existing `LICENSE`. Third-party data retain the terms of their original providers; the code license does not relicense those data.
