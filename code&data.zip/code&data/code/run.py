"""Stage driver for the revised (v2) analysis. Run from the package root:

  python code/run.py dev <workers>        development fits (train 1988-2005, validate 2006-2013, cut-off 2005)
  python code/run.py select               apply the registered selection rules -> config/config_v2.json
  python code/run.py fit <workers>        final fits on 1988-2013 (cut-off 2013): primary, competitors, variants
  python code/run.py post <workers>       forecasts 2014-2024, revised-solver diagnostics, joint Laplace, perception draws, synthetic recovery
All paths are relative to the package root. Outputs: out/<stage>/...
"""
import os, sys, json, time, itertools, glob
os.environ.setdefault("OMP_NUM_THREADS", "1"); os.environ.setdefault("MKL_NUM_THREADS", "1")
import numpy as np, torch
torch.set_num_threads(1)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
from models import *
from models import _flat_params
COMMODS = ["wheat", "maize", "rice", "soybeans"]
ARR = lambda c, spec: f"data/arrays/arrays_{c}_{spec}.npz"
DEV_TRAIN, DEV_EVAL = list(range(1988, 2006)), list(range(2006, 2014))
TRAIN, EVAL = list(range(1988, 2014)), list(range(2014, 2025))
GRID = dict(br_sig_alpha=[0.5, 1.0, 2.0], br_tau_scale=[0.25, 0.5, 1.0], gnn_h=[32, 64], gnn_wd=[1e-4, 1e-3], gnn_seeds=5,
            br_steps=2500, br_lbfgs=300, grav_ridge=0.01, gnn_max_epochs=600, synth_reps=20, perception_draws=200)
TAU = np.array([1.0, 2.0, 1.0, 1.0])


def save_json(obj, fn):
    tmp = fn + ".tmp"; json.dump(obj, open(tmp, "w")); os.replace(tmp, fn)


def br_params(mod):
    g, de, ph, om = [x.detach().numpy() for x in mod.params()]
    rho, th, ze, zp = [float(x) for x in mod.coefs()]
    return dict(gamma=g.tolist(), delta=de.tolist(), phi=ph.tolist(), omega=om.tolist(), u=mod.u.detach().numpy().tolist(),
                rho=rho, theta=th, eta=float(torch.exp(mod.leta)), kappa=float(Fnn.softplus(mod.lkappa)), zeta=ze, zeta_p=zp,
                mu_g=mod.mu_g.detach().numpy().tolist(), groups=mod.P.groups)


def cases_arrays(P, pred, years, h=1):
    cs = P.cases(years, h)
    S = np.array([np.nan_to_num(P.s[n, P.yi[t]]) for n, t in cs]); H = np.array([pred[t][n] for n, t in cs])
    return np.array([n for n, _ in cs]), np.array([t for _, t in cs]), S, H


# ============================================================== development
def dev_tasks():
    T = []
    for c in COMMODS:
        for sa, ts in itertools.product(GRID["br_sig_alpha"], GRID["br_tau_scale"]):
            T += [("BR", c, dict(sa=sa, ts=ts)), ("BR0", c, dict(sa=sa, ts=ts))]
        T += [("GRAV", c, {}), ("GRAVeq", c, {}), ("TERGM", c, {}), ("PERSIST", c, {})]
        for var in GNN_VARIANTS:
            for hh, wd in itertools.product(GRID["gnn_h"], GRID["gnn_wd"]):
                T += [(var, c, dict(h=hh, wd=wd, seed=s)) for s in range(GRID["gnn_seeds"])]
    return T


def tname(t):
    m, c, kw = t
    return f"{m}_{c}" + "".join(f"_{k}{v}" for k, v in sorted(kw.items()))


def dev_run(t):
    m, c, kw = t; nm = tname(t); out = "out/dev"; os.makedirs(out, exist_ok=True)
    if os.path.exists(f"{out}/{nm}.json"): return nm
    t0 = time.time(); P = Panel(ARR(c, "dev"), cutoff=2005); info = dict(task=nm, prep=P.prep)
    if m in ("BR", "BR0"):
        mod = BRModel(P, ablate_risk=(m == "BR0"), sig_alpha=kw["sa"], tau=tuple(kw["ts"] * TAU))
        info.update(fit_stack(mod, stack_years(P, DEV_TRAIN), steps=GRID["br_steps"], lbfgs_iter=GRID["br_lbfgs"]))
        pred = predict_stack(mod, P, DEV_EVAL); info["fp_resid_eval"] = mod.diag.get("max_resid", 0.0)
    elif m in ("GRAV", "GRAVeq"):
        mod = GravityPPML(P, ridge=GRID["grav_ridge"])
        info.update(fit_stack(mod, stack_years(P, DEV_TRAIN), weights="volume" if m == "GRAV" else "equal",
                              steps=GRID["br_steps"], lbfgs_iter=GRID["br_lbfgs"]))
        pred = predict_stack(mod, P, DEV_EVAL)
    elif m == "TERGM":
        pred = predict_tergm(P, fit_tergm(P, DEV_TRAIN), DEV_EVAL)
    elif m == "PERSIST":
        pred = predict_persistence(P, DEV_EVAL)
    else:
        net, gi = fit_gnn(P, DEV_TRAIN, DEV_EVAL, h=kw["h"], wd=kw["wd"], seed=kw["seed"], epochs=GRID["gnn_max_epochs"], risk=GNN_VARIANTS[m])
        info.update(best_val=gi["best_val"], best_epoch=gi["best_epoch"]); pred = predict_gnn([net], P, DEV_EVAL, risk=GNN_VARIANTS[m])
    n, tt, S, H = cases_arrays(P, pred, DEV_EVAL)
    np.savez_compressed(f"{out}/{nm}.npz", n=n, t=tt, s=S, shat=H)
    info["mean_kl"] = float(kl_loss(S, H).mean()); info["n_cases"] = int(len(S)); info["seconds"] = time.time() - t0
    save_json(info, f"{out}/{nm}.json"); return nm


def select():
    """Registered rules (Amendment A, applied to v2 development fits; BR0 now tuned separately):
    BR/BR0: (sigma_alpha, s) minimising pooled 2006-2013 mean KL per commodity. GNN variants: (h, wd) minimising the
    mean over seeds of single-seed validation KL; epochs = median best epoch of the seeds + 1. P* = lowest pooled
    development loss among PERSIST, GRAV, TERGM and the five-seed GNN ensemble."""
    rows = []; cfg = dict(GRID); cfg.update(br_sig_alpha={}, br_tau_scale={}, br0_sig_alpha={}, br0_tau_scale={})
    for v in GNN_VARIANTS: cfg[f"{v}_h"] = {}; cfg[f"{v}_wd"] = {}; cfg[f"{v}_epochs"] = {}
    J = {os.path.basename(f)[:-5]: json.load(open(f)) for f in glob.glob("out/dev/*.json")}
    for c in COMMODS:
        for m, key in [("BR", "br"), ("BR0", "br0")]:
            best = min(itertools.product(GRID["br_sig_alpha"], GRID["br_tau_scale"]),
                       key=lambda p: J[tname((m, c, dict(sa=p[0], ts=p[1])))]["mean_kl"])
            cfg[f"{key}_sig_alpha"][c] = best[0]; cfg[f"{key}_tau_scale"][c] = best[1]
            rows.append((c, m, J[tname((m, c, dict(sa=best[0], ts=best[1])))]["mean_kl"], f"sa={best[0]},s={best[1]}"))
        for m in ["GRAV", "GRAVeq", "TERGM", "PERSIST"]:
            rows.append((c, m, J[tname((m, c, {}))]["mean_kl"], ""))
        for v in GNN_VARIANTS:
            def score(p): return np.mean([J[tname((v, c, dict(h=p[0], wd=p[1], seed=s)))]["mean_kl"] for s in range(GRID["gnn_seeds"])])
            best = min(itertools.product(GRID["gnn_h"], GRID["gnn_wd"]), key=score)
            eps = [J[tname((v, c, dict(h=best[0], wd=best[1], seed=s)))]["best_epoch"] for s in range(GRID["gnn_seeds"])]
            cfg[f"{v}_h"][c] = best[0]; cfg[f"{v}_wd"][c] = best[1]; cfg[f"{v}_epochs"][c] = int(np.median(eps)) + 1
            zs = [np.load(f"out/dev/{tname((v, c, dict(h=best[0], wd=best[1], seed=s)))}.npz") for s in range(GRID["gnn_seeds"])]
            ens = np.mean([z["shat"] for z in zs], 0)
            rows.append((c, v, float(kl_loss(zs[0]["s"], ens).mean()), f"h={best[0]},wd={best[1]},ep={cfg[f'{v}_epochs'][c]}"))
    import pandas as pd
    df = pd.DataFrame(rows, columns=["c", "model", "kl", "choice"]); df.to_csv("out/dev/dev_selection_v2.csv", index=False)
    pooled = {}
    for m in ["PERSIST", "GRAV", "TERGM", "GNN"]:
        num = 0.0; den = 0
        for c in COMMODS:
            k = df[(df.c == c) & (df.model == m)].kl.iloc[0]; nn_ = J[tname(("PERSIST", c, {}))]["n_cases"]; num += k * nn_; den += nn_
        pooled[m] = num / den
    cfg["pstar"] = min(pooled, key=pooled.get); cfg["dev_pooled"] = pooled
    os.makedirs("config", exist_ok=True); save_json(cfg, "config/config_v2.json")
    print(df.pivot_table(index="c", columns="model", values="kl").round(4).to_string()); print(json.dumps(pooled))


# ============================================================== final fits
def CFG(): return json.load(open("config/config_v2.json"))


def make_br(P, c, ablate=False, cfg=None, sc=False, tau_mult=1.0, jitter=0.0, seed=0):
    cfg = cfg or CFG(); k = "br0" if ablate else "br"
    return BRModel(P, ablate_risk=ablate, sig_alpha=cfg[f"{k}_sig_alpha"][c], tau=tuple(cfg[f"{k}_tau_scale"][c] * tau_mult * TAU),
                   sign_constrained=sc, init_jitter=jitter, seed=seed)


BR_VARIANTS = {  # name: (array spec, peer scope, sign constrained, tau multiplier, init jitter, seed, horizon)
    "main": ("pre", "region", False, 1.0, 0.0, 0, 1), "h2": ("pre", "region", False, 1.0, 0.0, 0, 2),
    "s01": ("s01_pre", "region", False, 1.0, 0.0, 0, 1), "s09": ("s09_pre", "region", False, 1.0, 0.0, 0, 1),
    "cent": ("cent_pre", "region", False, 1.0, 0.0, 0, 1), "sevdur": ("sevdur_pre", "region", False, 1.0, 0.0, 0, 1),
    "legal": ("legal_pre", "region", False, 1.0, 0.0, 0, 1), "sign": ("pre", "region", True, 1.0, 0.0, 0, 1),
    "gpeer": ("pre", "global", False, 1.0, 0.0, 0, 1), "tau2": ("pre", "region", False, 2.0, 0.0, 0, 1),
    "start1": ("pre", "region", False, 1.0, 0.5, 1, 1), "start2": ("pre", "region", False, 1.0, 0.5, 2, 1)}
BR0_VARIANTS = ["main", "h2", "sevdur", "legal", "sign", "gpeer"]


def fit_tasks():
    T = []
    for c in COMMODS:
        T += [("BR", c, dict(v=v)) for v in BR_VARIANTS] + [("BR0", c, dict(v=v)) for v in BR0_VARIANTS]
        T += [("GRAV", c, dict(h=1)), ("GRAVeq", c, dict(h=1)), ("TERGM", c, dict(h=1)), ("GRAV", c, dict(h=2)), ("TERGM", c, dict(h=2))]
        for v in GNN_VARIANTS: T += [(v, c, dict(h=1, seed=s)) for s in range(GRID["gnn_seeds"])]
        T += [("GNN", c, dict(h=2, seed=s)) for s in range(GRID["gnn_seeds"])]
    return sorted(T, key=lambda t: (t[0] not in ("BR", "BR0"), t[1] != "wheat"))


def fit_run(t):
    m, c, kw = t; nm = tname(t); out = "out/fit"; os.makedirs(out, exist_ok=True)
    if os.path.exists(f"{out}/{nm}.json"): return nm
    cfg = CFG(); t0 = time.time()
    if m in ("BR", "BR0"):
        spec, scope, sc, tm, jit, seed, h = BR_VARIANTS[kw["v"]]
        P = Panel(ARR(c, spec), cutoff=2013, peer_scope=scope)
        mod = make_br(P, c, ablate=(m == "BR0"), cfg=cfg, sc=sc, tau_mult=tm, jitter=jit, seed=seed)
        st = stack_years(P, TRAIN, h)
        info = dict(task=nm, prep=P.prep, variant=kw["v"]); info.update(fit_stack(mod, st, steps=cfg["br_steps"], lbfgs_iter=cfg["br_lbfgs"]))
        torch.save(mod.state_dict(), f"{out}/{nm}.pt"); info["params"] = br_params(mod)
        if m == "BR" and kw["v"] == "main":
            pred = predict_stack(mod, P, TRAIN); cs = P.cases(TRAIN)
            S = np.array([np.nan_to_num(P.s[n, P.yi[t]]) for n, t in cs]); H = np.array([pred[t][n] for n, t in cs])
            num = (H * (1 - H)).sum(1).mean(); den = ((S - H) ** 2).sum(1).mean()
            info["dirichlet_conc"] = float(max(num / den - 1, 1.0)); info["insample_kl"] = float(kl_loss(S, H).mean())
    elif m in ("GRAV", "GRAVeq"):
        P = Panel(ARR(c, "pre"), cutoff=2013); mod = GravityPPML(P, ridge=cfg["grav_ridge"])
        info = dict(task=nm); info.update(fit_stack(mod, stack_years(P, TRAIN, kw["h"]), weights="volume" if m == "GRAV" else "equal",
                                                    steps=cfg["br_steps"], lbfgs_iter=cfg["br_lbfgs"]))
        torch.save(mod.state_dict(), f"{out}/{nm}.pt")
    elif m == "TERGM":
        P = Panel(ARR(c, "pre"), cutoff=2013); beta = fit_tergm(P, TRAIN, h=kw["h"]); np.save(f"{out}/{nm}_beta.npy", beta); info = dict(task=nm, beta=beta.tolist())
    else:
        P = Panel(ARR(c, "pre"), cutoff=2013)
        net, _ = fit_gnn(P, TRAIN, None, h=cfg[f"{m}_h"][c], wd=cfg[f"{m}_wd"][c], seed=kw["seed"], epochs=cfg[f"{m}_epochs"][c],
                         risk=GNN_VARIANTS[m], hz=kw["h"])
        torch.save(net.state_dict(), f"{out}/{nm}.pt"); info = dict(task=nm)
    info["seconds"] = time.time() - t0; save_json(info, f"{out}/{nm}.json"); return nm


# ============================================================== post-fit stages
def load_br(c, m="BR", v="main", P=None):
    spec, scope, sc, tm, jit, seed, h = BR_VARIANTS[v]
    P = P or Panel(ARR(c, spec.replace("_pre", "_full").replace("pre", "full")), cutoff=2013, peer_scope=scope)
    mod = make_br(P, c, ablate=(m == "BR0"), sc=sc, tau_mult=tm, jitter=jit, seed=seed)
    mod.load_state_dict(torch.load(f"out/fit/{m}_{c}_v{v}.pt")); return mod, P, h


def predict_run(c):
    out = "out/post"; os.makedirs(out, exist_ok=True); fn = f"{out}/pred_{c}.npz"
    if os.path.exists(fn): return fn
    cfg = CFG(); res = {}; extra = {}
    Pf = Panel(ARR(c, "full"), cutoff=2013)
    for m, vs in [("BR", list(BR_VARIANTS)), ("BR0", BR0_VARIANTS)]:
        for v in vs:
            mod, P, h = load_br(c, m, v)
            res[(f"{m}_{v}", h)] = predict_stack(mod, P, EVAL, h=h)
            if v == "main": extra[f"peer_fallback_{m}"] = dict(P.peer_fallback)
    for h in (1, 2):
        g = GravityPPML(Pf, ridge=cfg["grav_ridge"]); g.load_state_dict(torch.load(f"out/fit/GRAV_{c}_h{h}.pt")); res[("GRAV", h)] = predict_stack(g, Pf, EVAL, h=h)
        res[("TERGM", h)] = predict_tergm(Pf, np.load(f"out/fit/TERGM_{c}_h{h}_beta.npy"), EVAL, h=h)
        res[("PERSIST", h)] = predict_persistence(Pf, EVAL, h=h)
    g = GravityPPML(Pf, ridge=cfg["grav_ridge"]); g.load_state_dict(torch.load(f"out/fit/GRAVeq_{c}_h1.pt")); res[("GRAVeq", 1)] = predict_stack(g, Pf, EVAL)
    for v, hs in [("GNN", (1, 2)), ("GNNfull", (1,)), ("GNNnet", (1,))]:
        for h in hs:
            nets = []
            for s in range(GRID["gnn_seeds"]):
                net = BipartiteGNN(Pf.N, Pf.K, len(Pf.groups), h=cfg[f"{v}_h"][c], risk=GNN_VARIANTS[v]).float()
                net.load_state_dict(torch.load(f"out/fit/{v}_{c}_h{h}_seed{s}.pt")); nets.append(net)
            res[(v, h)] = predict_gnn(nets, Pf, EVAL, risk=GNN_VARIANTS[v], h=h)
            if v == "GNN" and h == 1:
                for s in range(GRID["gnn_seeds"]): res[(f"GNNseed{s}", 1)] = predict_gnn([nets[s]], Pf, EVAL, risk="diag")
    o = {}
    for h in (1, 2):
        cs = Pf.cases(EVAL, h); o[f"n_h{h}"] = np.array([n for n, _ in cs]); o[f"t_h{h}"] = np.array([t for _, t in cs])
        o[f"s_h{h}"] = np.array([np.nan_to_num(Pf.s[n, Pf.yi[t]]) for n, t in cs])
        for (m, hh), pr in res.items():
            if hh == h: o[f"shat_{m}_h{h}"] = np.array([pr[t][n] for n, t in cs])
    np.savez_compressed(fn, **o); save_json({k: {str(a): b for a, b in v.items()} for k, v in extra.items()}, f"{out}/peerfallback_{c}.json")
    return fn


def solver_audit(c):
    """Residuals, tolerance sensitivity and independent SLSQP solutions for the revised model,
    including the stiffest importer-year problems. Historical v1 comparisons are outside this export."""
    out = "out/post"; fn = f"{out}/solver_{c}.json"
    if os.path.exists(fn): return fn
    from scipy.optimize import minimize
    mod, P, h = load_br(c); st = stack_years(P, EVAL)
    d = solution_diagnostics(mod, st); msk = st["msk"].numpy() > 0
    r = dict(l1_q=np.quantile(d["l1"][msk], [0.5, 0.9, 0.99, 1.0]).tolist(), fw_q=np.quantile(d["fw_gap"][msk], [0.5, 0.9, 0.99, 1.0]).tolist(),
             newton_iters=d["info"]["iters"])
    with torch.no_grad():
        s_a, _ = mod.forward_stack(st, tol=1e-8); s_b, _ = mod.forward_stack(st, tol=1e-13)
    r["tol_maxabs_share_diff"] = float((s_a - s_b).abs().amax(2)[torch.tensor(msk)].max())
    # SLSQP on a sample
    yy, nn_ = np.where(msk); rng = np.random.default_rng(7)
    stiff = np.argsort(-d["gnorm"][yy, nn_])[:100]; rand = rng.choice(len(yy), 200, replace=False)
    diffs, gaps = [], []
    for i in np.unique(np.concatenate([stiff, rand])):
        y, n = yy[i], nn_[i]; v = d["v"][y, n]; G = d["gS"][y, n]; a = P.avail[n] > 0
        va, Ga = v[a], G[np.ix_(a, a)]
        f = lambda w: -va @ w + 0.5 * w @ Ga @ w + np.sum(w * np.log(np.maximum(w, 1e-300)))
        jac = lambda w: -va + Ga @ w + np.log(np.maximum(w, 1e-300)) + 1
        sol = minimize(f, np.full(a.sum(), 1 / a.sum()), jac=jac, method="SLSQP", bounds=[(1e-15, 1)] * int(a.sum()),
                       constraints=[dict(type="eq", fun=lambda w: w.sum() - 1, jac=lambda w: np.ones_like(w))], options=dict(ftol=1e-15, maxiter=1000))
        wn = d["w"][y, n][a]; diffs.append(float(np.abs(sol.x - wn).sum())); gaps.append(float(f(wn) - f(sol.x)))
    r.update(slsqp_n=len(diffs), slsqp_l1_max=max(diffs), slsqp_l1_median=float(np.median(diffs)), objective_newton_minus_slsqp_max=max(gaps))
    save_json(r, fn); return fn


def laplace_run(c):
    out = "out/post"; fn = f"{out}/laplace_{c}.npz"
    if os.path.exists(fn): return fn
    mod, P, _ = load_br(c, P=Panel(ARR(c, "pre"), cutoff=2013)); st = stack_years(P, TRAIN)
    conc = json.load(open(f"out/fit/BR_{c}_vmain.json"))["dirichlet_conc"]
    Hn, Hp, idx = joint_hessian(mod, st)
    L1 = laplace_summary(Hn, Hp, idx, 1.0); L2 = laplace_summary(Hn, Hp, idx, conc + 1.0)
    # perception draws from the unit-weight joint Gaussian
    rng = np.random.default_rng(11); D = Hn.shape[0]
    plist = _flat_params(mod); base = torch.cat([p.detach().reshape(-1) for p in plist]).numpy()
    Lc = np.linalg.cholesky(L1["cov"] + 1e-12 * np.eye(D))
    draws = base[None] + (rng.standard_normal((GRID["perception_draws"], D)) @ Lc.T)
    np.savez_compressed(fn, **{f"unit_{k}": v for k, v in L1.items() if k != "cov"}, **{f"cal_{k}": v for k, v in L2.items() if k != "cov"},
                        conc=conc, draws=draws.astype(np.float32), base=base)
    return fn


def perception_run(c):
    """portfolio sensitivity to parameter perturbations (point estimate and Laplace draws), years 2014-2023"""
    out = "out/post"; fn = f"{out}/perception_{c}.npz"
    if os.path.exists(fn): return fn
    mod, P, _ = load_br(c); yrs = list(range(2014, 2024)); st = stack_years(P, yrs)
    lz = np.load(f"{out}/laplace_{c}.npz"); plist = _flat_params(mod); offs = np.cumsum([0] + [p.numel() for p in plist])
    def setv(vec):
        with torch.no_grad():
            for p, a, b in zip(plist, offs[:-1], offs[1:]): p.copy_(torch.tensor(vec[a:b], dtype=torch.float64).view_as(p))
    names = ["actual", "zero_distance", "zero_memory", "zero_mixing", "all_three", "half_delta", "half_kappa"]
    def run():
        g, de, ph, om = mod.params()
        ovs = dict(actual={}, zero_distance=dict(delta=torch.zeros_like(de)), zero_memory=dict(eta=torch.tensor(0.0)),
                   zero_mixing=dict(omega=torch.zeros_like(om)), all_three=dict(delta=torch.zeros_like(de), eta=torch.tensor(0.0), omega=torch.zeros_like(om)),
                   half_delta=dict(delta=0.5 * de), half_kappa=dict(polscale=0.5))
        sh = {}
        with torch.no_grad():
            for k in names: sh[k], _ = mod.forward_stack(st, ovs[k])
        SIG = st["SIG"]; msk = st["msk"].numpy() > 0
        L1 = {k: 0.5 * (sh[k] - sh["actual"]).abs().sum(2).numpy() for k in names[1:]}
        var = {k: torch.einsum("ynk,ykl,ynl->yn", sh[k], SIG, sh[k]).numpy() for k in names}
        dv = {k: var[k] / np.maximum(var["actual"], 1e-12) - 1 for k in names[1:]}
        mean = lambda a: np.array([a[:, n][msk[:, n]].mean() if msk[:, n].any() else np.nan for n in range(P.N)])
        return np.array([mean(L1[k]) for k in names[1:]]), np.array([mean(dv[k]) for k in names[1:]])
    L1p, dvp = run(); L1d, dvd = [], []
    for k in range(lz["draws"].shape[0]):
        setv(lz["draws"][k].astype(np.float64)); a, b = run(); L1d.append(a); dvd.append(b)
    setv(lz["base"])
    np.savez_compressed(fn, names=np.array(names[1:]), L1_point=L1p, dv_point=dvp, L1_draws=np.array(L1d, np.float32), dv_draws=np.array(dvd, np.float32))
    return fn


def simulate(P, mod, conc, rng):
    """sequential simulation 1988-2013 from the fitted model: Dirichlet(conc * shat) with component floor 1e-3 on
    available suppliers, components with simulated share < 1e-4 set to zero and the vector renormalised (sparse
    Dirichlet observation process); 1986-1987 observed shares and observed volumes retained."""
    Ps = Panel.__new__(Panel); Ps.__dict__.update(P.__dict__); Ps.s = P.s.copy(); Ps.peer_fallback = {}
    for t in TRAIN:
        b = P.yi[t]; st = stack_years(Ps, [t])
        with torch.no_grad(): shat, _ = mod.forward_stack(st)
        sh = shat[0].numpy()
        for n in range(P.N):
            if not P.valid[n, b]: continue
            a = np.maximum(conc * sh[n], 1e-3) * P.avail[n]
            x = rng.gamma(np.where(a > 0, a, 1e-9)) * (P.avail[n] > 0)
            x = np.where(x / max(x.sum(), 1e-300) < 1e-4, 0, x); Ps.s[n, b] = x / max(x.sum(), 1e-300)
    return Ps


def synth_run(args):
    c, rep = args; out = "out/synth"; os.makedirs(out, exist_ok=True); fn = f"{out}/synth_{c}_{rep}.npz"
    if os.path.exists(fn): return fn
    P = Panel(ARR(c, "pre"), cutoff=2013); truth, _, _ = load_br(c, P=P)
    conc = json.load(open(f"out/fit/BR_{c}_vmain.json"))["dirichlet_conc"]
    rng = np.random.default_rng(1000 + rep); Ps = simulate(P, truth, conc, rng)
    jit = 0.5 if rep >= GRID["synth_reps"] // 2 else 0.0
    est = make_br(Ps, c, jitter=jit, seed=rep); st = stack_years(Ps, TRAIN)
    fi = fit_stack(est, st, steps=CFG()["br_steps"], lbfgs_iter=CFG()["br_lbfgs"])
    Hn, Hp, idx = joint_hessian(est, st); L = laplace_summary(Hn, Hp, idx, 1.0); Lc = laplace_summary(Hn, Hp, idx, conc + 1.0)
    np.savez_compressed(fn, u_true=truth.u.detach().numpy(), u_hat=est.u.detach().numpy(), mu_true=truth.mu_g.detach().numpy(),
                        mu_hat=est.mu_g.detach().numpy(), u_sd=L["u_sd"], dev_sd=L["dev_sd"], u_sd_cond=L["u_sd_conditional"], mu_sd=L["mu_sd"],
                        u_sd_cal=Lc["u_sd"], mu_sd_cal=Lc["mu_sd"], gid=P.gid, jitter=jit, pd=L["pd"], min_eig=L["min_eig"],
                        glob_true=np.array([float(x) for x in [truth.rho, truth.theta, truth.leta, truth.lkappa, truth.zeta, truth.zeta_p]]),
                        glob_hat=np.array([float(x) for x in [est.rho, est.theta, est.leta, est.lkappa, est.zeta, est.zeta_p]]), loss=fi["loss"])
    return fn


def post_tasks():
    T = [("predict", c) for c in COMMODS] + [("solver", c) for c in COMMODS] + [("laplace", c) for c in COMMODS]
    T += [("synth", (c, r)) for c in COMMODS for r in range(GRID["synth_reps"])]
    return T


def post_run(t):
    k, a = t
    if k == "laplace":
        laplace_run(a); return perception_run(a)
    return dict(predict=predict_run, solver=solver_audit, synth=synth_run)[k](a)


def _guard(f, t):
    return f(t)



def dev_safe(t): return _guard(dev_run, t)


def fit_safe(t): return _guard(fit_run, t)


if __name__ == "__main__":
    import multiprocessing as mp
    stage = sys.argv[1]; nw = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    if stage == "select": select(); sys.exit()
    T, f = {"dev": (dev_tasks(), dev_safe), "fit": (fit_tasks(), fit_safe), "post": (post_tasks(), post_run)}[stage]
    if len(sys.argv) > 3: T = [t for t in T if sys.argv[3] in str(t)]
    print(stage, len(T), "tasks", flush=True); t0 = time.time()
    if nw == 1:
        for t in T: print(round(time.time() - t0), "done", f(t), flush=True)
        sys.exit()
    with mp.get_context("fork" if sys.platform != "win32" else "spawn").Pool(min(nw, len(T))) as pool:
        for r in pool.imap_unordered(f, T):
            print(round(time.time() - t0), "done", r, flush=True)
