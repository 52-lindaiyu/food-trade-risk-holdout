"""Real-time yield anomalies, supplier covariance and policy-risk components for the reference risk landscape.

anomaly a_js = log Y_js - linear trend fitted to log Y over s-15..s-1 (extrapolated to s)
standardised shock z_js = a_js / sd(a over s-25..s-1, >= 10 obs)
Sigma_t (t = forecast year) uses anomalies in [t-25, t-1]:
   Sigma_t = B Cov(f) B' + LedoitWolf(residuals) + diag(pi_jt * SIGMA2_POL)
"""
import numpy as np, pandas as pd

SIGMA2_POL = 0.2 ** 2  # a coded restriction year is treated as a 20% supply loss (log units, squared)
TELE_COLS = ["N34_DJF", "N34_JAS", "DMI_SON", "DMI_SON_lag", "NAO_DJFM"]


def realtime_anomalies(logy, years):
    """logy: array over years (NaN allowed). returns a (anomaly), z (standardised)."""
    n = len(years); a = np.full(n, np.nan); z = np.full(n, np.nan)
    for k in range(n):
        lo = max(0, k - 15); x = np.arange(lo, k); y = logy[lo:k]; ok = np.isfinite(y)
        if ok.sum() >= 8 and np.isfinite(logy[k]):
            b = np.polyfit(x[ok], y[ok], 1); a[k] = logy[k] - np.polyval(b, k)
    for k in range(n):
        past = a[max(0, k - 25):k]; past = past[np.isfinite(past)]
        if len(past) >= 10 and np.isfinite(a[k]):
            z[k] = a[k] / max(past.std(ddof=1), 1e-3)
    return a, z


def ledoit_wolf(X):
    """Ledoit-Wolf shrinkage towards scaled identity. X: n x p (centred inside)."""
    X = X - X.mean(0); n, p = X.shape
    S = X.T @ X / n; mu = np.trace(S) / p; F = mu * np.eye(p)
    d2 = ((S - F) ** 2).sum()
    b2 = sum((((x[:, None] * x[None, :]) - S) ** 2).sum() for x in X) / n ** 2
    b2 = min(b2, d2); shrink = b2 / d2 if d2 > 0 else 1.0
    return shrink * F + (1 - shrink) * S, shrink


def sigma_t(A, tele, pol, years, t, ridge=1.0, window=25, tele_on=True, sigma2_pol=SIGMA2_POL, centered=False):
    """A: K x nyears anomaly matrix (suppliers), tele: nyears x 5, pol: K x nyears restriction indicator."""
    yi = np.array(years); sel = (yi >= t - window) & (yi <= t - 1)
    X = A[:, sel].T  # n x K
    F = tele[sel]
    ok = np.isfinite(X).all(1) & np.isfinite(F).all(1)
    X = X[ok]; F = F[ok]
    Fm = F.mean(0); Fs = F.std(0, ddof=1); Fz = (F - Fm) / Fs
    Xc = X - X.mean(0)
    if tele_on:
        Bz = np.linalg.solve(Fz.T @ Fz + ridge * np.eye(Fz.shape[1]), Fz.T @ Xc)  # 5 x K
        fit = Fz @ Bz; R = Xc - fit
        Stele = Bz.T @ np.cov(Fz.T) @ Bz
    else:
        R = Xc; Stele = np.zeros((X.shape[1], X.shape[1])); Bz = None
    Sres, shrink = ledoit_wolf(R)
    pi = np.nanmean(pol[:, sel], axis=1)
    Spol = np.diag((pi * (1 - pi) if centered else pi) * sigma2_pol)
    return Stele + Sres + Spol, dict(Stele=Stele, Sres=Sres, Spol=Spol, B=Bz, shrink=shrink, n=len(X))
