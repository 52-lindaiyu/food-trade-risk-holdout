"""Revised implementation (v2) of the behavioural portfolio model (BR), its risk-free ablation (BR0) and the
phenomenological / learned competitors. This export contains the corrected analysis described in the paper.
Compatible with torch 2.0 / numpy 1.26 (original environment: torch 2.0.1).

Information convention: a forecast for year t with horizon h uses trade shares, volumes and unit values dated <= t-h,
supplier anomalies and restriction indicators dated <= t-h, and the covariance computed from anomalies in [t-h-24, t-h].
All learned preprocessing constants (covariance scale, unit-value imputation medians) use years <= `cutoff` only.
"""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as Fnn

torch.set_default_dtype(torch.float64)
FLOOR = 1e-4
EPS_LAG = 0.005
LMEM = 30          # finite memory length (years); weights phi^l normalised over available lags
NEG = -60.0        # utility offset for unavailable suppliers (own country); exp(-60) ~ 1e-26
TOL = 1e-11        # Newton fixed-point tolerance (max abs logit residual)


# ----------------------------------------------------------------------------- data
class Panel:
    def __init__(self, path, cutoff=2013, peer_scope="region"):
        z = np.load(path, allow_pickle=False)
        self.path = path; self.cutoff = int(cutoff); self.peer_scope = peer_scope
        self.I = list(z["I"]); self.S = list(z["S"]); self.years = [int(y) for y in z["years"]]; self.ally = [int(y) for y in z["ally"]]
        self.Q = z["Q"]; self.UV = z["UV"]; self.TOT = z["TOT"]; self.A = z["A"]; self.Z = z["Z"]; self.POL = z["POL"]
        self.SIG = z["SIG"]; self.D = z["D"]; self.CT = z["CT"]; self.CL = z["CL"]
        self.reg = list(z["reg"]); self.inc = list(z["inc"])
        N, T, K = self.Q.shape; self.N, self.T, self.K = N, T, K
        tot = np.nansum(self.Q, 2)
        self.valid = np.isfinite(self.Q[:, :, 0]) & (tot > 0)
        self.s = np.where(self.valid[:, :, None], self.Q / np.where(tot > 0, tot, 1)[:, :, None], np.nan)
        self.vol = np.where(self.valid, tot, 0.0)
        self.avail = np.ones((N, K))
        for a, i in enumerate(self.I):
            if i in self.S[:-1]: self.avail[a, self.S.index(i)] = 0.0
        self.drel = (self.D - self.D.min(1, keepdims=True)) / 1e4
        self.logd = np.log(self.D)
        g = [f"{r}|{c}" for r, c in zip(self.reg, self.inc)]
        self.groups = sorted(set(g)); self.gid = np.array([self.groups.index(x) for x in g])
        regs = sorted(set(self.reg)); self.rid = np.array([regs.index(x) for x in self.reg])
        yrs = np.array(self.years); pre = yrs <= self.cutoff
        # unit values: supplier median over years <= cutoff, then global median over years <= cutoff
        uv = np.where(self.UV > 0, self.UV, np.nan)
        self.uv_missing = ~np.isfinite(uv)
        fill = np.array([np.nanmedian(uv[k][pre]) if np.isfinite(uv[k][pre]).any() else np.nan for k in range(K)])
        gfill = float(np.nanmedian(uv[:, pre]))
        fill = np.where(np.isfinite(fill), fill, gfill)
        uv = np.where(np.isfinite(uv), uv, fill[:, None])
        self.luv = np.log(uv)
        tt = np.where(np.isfinite(self.TOT), self.TOT, 0.0); self.ltot = np.log1p(tt)
        # covariance scale: median supplier variance over forecast years <= cutoff
        diag = np.array([np.diag(self.SIG[b]) for b in range(T) if self.years[b] <= self.cutoff])
        self.sig_scale = float(np.median(diag))
        self.SIGn = self.SIG / self.sig_scale
        self.prep = dict(cutoff=self.cutoff, sig_scale=self.sig_scale, uv_fill=fill.tolist(), uv_global_fill=gfill,
                         uv_imputed_cells_le_cutoff=int(self.uv_missing[:, pre].sum()),
                         uv_imputed_cells_after_cutoff=int(self.uv_missing[:, ~pre].sum()))
        zz = np.nan_to_num(self.Z, nan=0.0)
        self.zvalid = np.isfinite(self.Z).astype(float)
        self.shock = np.clip(-zz, 0.0, 3.0) ** 2
        self.yi = {y: b for b, y in enumerate(self.years)}
        self.ai = {y: b for b, y in enumerate(self.ally)}
        self.peer_fallback = {}

    def lag_shares(self, t, lag=1):
        return np.nan_to_num(self.s[:, self.yi[t - lag]], nan=0.0)

    def peer_shares(self, t, lag=1):
        """volume-weighted shares at t-lag of the other importers in the same World Bank region (or all importers)"""
        b = self.yi[t - lag]; s = np.nan_to_num(self.s[:, b], nan=0.0); v = self.vol[:, b]
        out = np.zeros_like(s); nfb = 0
        for n in range(self.N):
            m = (self.rid == self.rid[n]) if self.peer_scope == "region" else np.ones(self.N, bool)
            m = m.copy(); m[n] = False
            w = v * m
            if w.sum() <= 0: w = v.copy(); w[n] = 0; nfb += 1
            out[n] = (w[:, None] * s).sum(0) / max(w.sum(), 1e-12)
        self.peer_fallback[t] = nfb
        out = out * self.avail; out = out / np.maximum(out.sum(1, keepdims=True), 1e-12)
        return out

    def cases(self, years, h=1):
        out = []
        for t in years:
            if t - h - 1 < self.years[0]: continue
            b = self.yi[t]; b1 = self.yi[t - 1]; bh = self.yi[t - h]
            for n in range(self.N):
                if self.valid[n, b] and self.valid[n, b1] and self.valid[n, bh]: out.append((n, t))
        return out


def kl_loss(s, shat, floor=FLOOR, avail=None):
    """KL(s || shat) of a compositional point forecast. Forecast shares are floored at `floor` and renormalised; if
    `avail` (cases x K) is given, flooring is applied to available suppliers only."""
    a = np.ones_like(shat) if avail is None else avail
    shat = np.where(a > 0, np.maximum(shat, floor), 0.0); shat = shat / shat.sum(-1, keepdims=True)
    m = s > 0
    return np.where(m, s * np.log(np.where(m, s, 1) / np.where(m, shat, 1)), 0.0).sum(-1)


def hellinger(s, shat, floor=FLOOR, avail=None):
    a = np.ones_like(shat) if avail is None else avail
    shat = np.where(a > 0, np.maximum(shat, floor), 0.0); shat = shat / shat.sum(-1, keepdims=True)
    return np.sqrt(0.5 * ((np.sqrt(s) - np.sqrt(shat)) ** 2).sum(-1))


# ----------------------------------------------------------------------------- information sets
def year_batch(P, t, h=1):
    """information for forecasting year t at horizon h (everything dated <= t-h)"""
    tl = t - h; a1 = P.ai[tl]
    d = dict(slag=P.lag_shares(t, h), slag2=P.lag_shares(t, h + 1),
             peer=P.peer_shares(t, h), luv=P.luv[:, P.yi[tl]] - P.luv[:, P.yi[tl]].mean(),
             ltot=P.ltot[:, P.yi[tl]], SIG=P.SIGn[P.yi[tl + 1]],
             shock=P.shock[:, :a1 + 1], pol=P.POL[:, :a1 + 1], zv=P.zvalid[:, :a1 + 1],
             z1=np.nan_to_num(P.Z[:, a1]), z2=np.nan_to_num(P.Z[:, a1 - 1]), z3=np.nan_to_num(P.Z[:, a1 - 2]),
             p1=P.POL[:, a1], p2=P.POL[:, a1 - 1], p3=P.POL[:, a1 - 2], t=t, h=h)
    return d


def stack_years(P, years, h=1):
    years = [t for t in years if t - h - 1 >= P.years[0]]
    ds = [year_batch(P, t, h) for t in years]
    H = np.zeros((len(years), LMEM, P.K)); HP = np.zeros((len(years), LMEM, P.K)); HV = np.zeros((len(years), LMEM, P.K))
    for y, d in enumerate(ds):
        L = min(LMEM, d["shock"].shape[1])
        H[y, :L] = d["shock"][:, ::-1][:, :L].T; HP[y, :L] = d["pol"][:, ::-1][:, :L].T; HV[y, :L] = d["zv"][:, ::-1][:, :L].T
    st = dict(years=years, h=h,
              slag=np.stack([d["slag"] for d in ds]), peer=np.stack([d["peer"] for d in ds]),
              luv=np.stack([d["luv"] for d in ds]), ltot=np.stack([d["ltot"] for d in ds]),
              z1=np.stack([d["z1"] for d in ds]), p1=np.stack([d["p1"] for d in ds]),
              SIG=np.stack([d["SIG"] for d in ds]), H=H, HP=HP, HV=HV,
              X1=np.stack([np.nan_to_num(P.Q[:, P.yi[t - h]], nan=0.0) for t in years]),
              tt=np.array([(t - 2000) / 10.0 for t in years]),
              tgt=np.stack([np.nan_to_num(P.s[:, P.yi[t]], nan=0.0) for t in years]),
              msk=np.stack([(P.valid[:, P.yi[t]] & P.valid[:, P.yi[t - 1]] & P.valid[:, P.yi[t - h]]).astype(float) for t in years]),
              vol=np.stack([P.vol[:, P.yi[t]] for t in years]))
    return {k: (torch.tensor(v) if isinstance(v, np.ndarray) else v) for k, v in st.items()}


# ----------------------------------------------------------------------------- fixed-point solver
def newton_fixed_point(v, gS, x0=None, tol=TOL, max_iter=100):
    """Solve x = v - gS softmax(x) (batched; gS = gamma * perceived covariance, symmetric PSD per batch element).
    Equivalent to the KKT condition of  min_w  -v'w + 1/2 w' gS w + sum w log w  on the simplex (strictly convex).
    Damped Newton with backtracking on the max-abs residual; returns x, w and diagnostics."""
    x = v.clone() if x0 is None else x0.clone()
    eye = torch.eye(v.shape[-1], dtype=v.dtype)
    def resid(x):
        w = torch.softmax(x, -1); return x - v + torch.einsum("...kl,...l->...k", gS, w), w
    r, w = resid(x); nr = r.abs().amax(-1); it = 0
    for it in range(max_iter):
        if float(nr.max()) < tol: break
        A = torch.diag_embed(w) - w[..., :, None] * w[..., None, :]
        J = eye + gS @ A
        dx = torch.linalg.solve(J, r[..., None])[..., 0]
        lam = torch.ones_like(nr)
        for _ in range(30):
            xn = x - lam[..., None] * dx; rn, wn = resid(xn); nrn = rn.abs().amax(-1)
            bad = (nrn > nr * (1 - 1e-4 * lam)) & (nr > tol)
            if not bool(bad.any()): break
            lam = torch.where(bad, lam * 0.5, lam)
        x, r, w, nr = xn, rn, wn, nrn
    return x, w, dict(iters=it, max_resid=float(nr.max()))


class _ImplicitGrad(torch.autograd.Function):
    """identity in the forward pass; in the backward pass maps g -> (I - J)^{-T} g with J = dF/dw at the fixed point,
    which turns the gradient of F(w*) w.r.t. parameters (w* held fixed) into the exact implicit-function gradient."""
    @staticmethod
    def forward(ctx, w, M):
        ctx.save_for_backward(M); return w.clone()

    @staticmethod
    def backward(ctx, g):
        (M,) = ctx.saved_tensors  # M = (I - J)^T
        return torch.linalg.solve(M, g[..., None])[..., 0], None


class BRModel(nn.Module):
    """Behavioural model. ablate_risk=True fixes gamma=0 (BR0). sign_constrained=True forces theta, zeta, zeta_p >= 0."""
    def __init__(self, P, ablate_risk=False, sig_alpha=2.0, tau=(1.0, 2.0, 1.0, 1.0), sign_constrained=False, init_jitter=0.0, seed=0):
        super().__init__()
        N, K = P.N, P.K; G = len(P.groups)
        self.P = P; self.ablate = ablate_risk; self.sig_alpha = sig_alpha; self.sc = sign_constrained
        self.tau = torch.tensor(tau)
        self.alpha = nn.Parameter(torch.zeros(N, K))
        init = torch.tensor([0.0, 0.0, 0.0, -2.0])
        gen = torch.Generator().manual_seed(seed)
        self.u = nn.Parameter(torch.zeros(N, 4) + init + init_jitter * torch.randn(N, 4, generator=gen))
        self.mu_g = nn.Parameter(torch.zeros(G, 4) + init)
        self.rho = nn.Parameter(torch.tensor(1.0)); self.theta = nn.Parameter(torch.tensor(0.0))
        self.leta = nn.Parameter(torch.tensor(0.0)); self.lkappa = nn.Parameter(torch.tensor(0.0))
        self.zeta = nn.Parameter(torch.tensor(0.0)); self.zeta_p = nn.Parameter(torch.tensor(0.0))
        self.avail = torch.tensor(P.avail); self.drel = torch.tensor(P.drel); self.gid = torch.tensor(P.gid)
        self.prep = dict(P.prep)
        self._x0 = {}; self.diag = {}

    def params(self):
        g = torch.exp(self.u[:, 0]); delta = self.u[:, 1]; phi = torch.sigmoid(self.u[:, 2]); om = torch.sigmoid(self.u[:, 3])
        if self.ablate: g = torch.zeros_like(g)
        return g, delta, phi, om

    def coefs(self):
        f = (lambda x: Fnn.softplus(x)) if self.sc else (lambda x: x)
        return self.rho, f(self.theta), f(self.zeta), f(self.zeta_p)

    def utilities(self, st):
        rho, theta, zeta, zeta_p = self.coefs()
        v = self.alpha[None] + rho * torch.log(st["slag"] + EPS_LAG) - theta * st["luv"][:, None, :] \
            + zeta * st["z1"][:, None, :] - zeta_p * st["p1"][:, None, :]
        return torch.where((self.avail == 0)[None], torch.full_like(v, NEG), v)

    def perceived(self, st, g, delta, phi, ov):
        """gamma * perceived covariance, Y x N x K x K"""
        SIG = ov.get("sig", st["SIG"])
        eta = ov.get("eta", torch.exp(self.leta))
        kap = Fnn.softplus(self.lkappa) * ov.get("polscale", 1.0)
        lag = torch.arange(LMEM, dtype=torch.float64)
        Wm = phi[:, None] ** lag[None, :]                                   # N x L (unnormalised)
        Hx = st["H"] + kap * st["HP"]                                       # Y x L x K
        num = torch.einsum("nl,ylk->ynk", Wm, Hx * st["HV"])
        den = torch.einsum("nl,ylk->ynk", Wm, st["HV"]).clamp_min(1e-12)
        M = num / den                                                       # normalised finite memory
        Dm = torch.exp(-delta[:, None] * self.drel)                         # N x K
        St = Dm[None, :, :, None] * SIG[:, None] * Dm[None, :, None, :] + torch.diag_embed(eta * M * Dm[None] ** 2)
        av = self.avail[None, :, :, None] * self.avail[None, :, None, :]
        return g[None, :, None, None] * St * av

    def forward_stack(self, st, override=None, key=None, tol=TOL):
        ov = override or {}
        g, delta, phi, om = self.params()
        g = ov.get("gamma", g); delta = ov.get("delta", delta); phi = ov.get("phi", phi); om = ov.get("omega", om)
        v = self.utilities(st)
        if self.ablate and "gamma" not in ov:
            w = torch.softmax(v, 2); self.diag = dict(iters=0, max_resid=0.0)
        else:
            gS = self.perceived(st, g, delta, phi, ov)
            with torch.no_grad():
                x0 = self._x0.get(key) if key is not None else None
                if x0 is not None and x0.shape != v.shape: x0 = None
                x, ws, info = newton_fixed_point(v.detach(), gS.detach(), x0=x0, tol=tol)
                if key is not None: self._x0[key] = x
                A = torch.diag_embed(ws) - ws[..., :, None] * ws[..., None, :]
                Mt = torch.eye(v.shape[-1]) + gS.detach() @ A                 # (I - J)^T, J = -A gS
            w = torch.softmax(v - torch.einsum("ynkl,ynl->ynk", gS, ws), 2)  # = ws at the fixed point
            if torch.is_grad_enabled(): w = _ImplicitGrad.apply(w, Mt)
            self.diag = info
        shat = (1 - om)[None, :, None] * w + om[None, :, None] * st["peer"]
        return shat, w

    def penalty(self):
        pen = 0.5 * (self.alpha ** 2).sum() / self.sig_alpha ** 2
        dev = (self.u - self.mu_g[self.gid]) / self.tau
        pen = pen + 0.5 * (dev ** 2).sum()
        pen = pen + 0.5 * ((self.mu_g - self.mu_g.mean(0, keepdim=True)) ** 2).sum()
        pen = pen + 0.5 * (self.leta ** 2 + self.lkappa ** 2) / 4.0   # log eta ~ N(0, 2^2); l_kappa ~ N(0, 2^2), kappa = softplus(l_kappa)
        return pen


def solution_diagnostics(mod, st, override=None):
    """undamped fixed-point residual ||softmax(v - gS w) - w||_1, logit residual and Frank-Wolfe duality gap (an upper
    bound on the objective sub-optimality of the convex portfolio problem) for every importer-year in the stack."""
    with torch.no_grad():
        ov = override or {}
        g, delta, phi, om = mod.params(); v = mod.utilities(st)
        if mod.ablate: return None
        gS = mod.perceived(st, g, delta, phi, ov)
        x, w, info = newton_fixed_point(v, gS)
        Fw = torch.softmax(v - torch.einsum("ynkl,ynl->ynk", gS, w), 2)
        l1 = (Fw - w).abs().sum(2)
        grad = -v + torch.einsum("ynkl,ynl->ynk", gS, w) + torch.log(w.clamp_min(1e-300)) + 1
        un = (mod.avail == 0)[None].expand_as(grad)
        fw_gap = torch.where(un, torch.zeros_like(grad), grad * w).sum(2) - torch.where(un, torch.full_like(grad, float("inf")), grad).amin(2)
        gscale = torch.linalg.matrix_norm(gS, ord=2)
    return dict(l1=l1.numpy(), fw_gap=fw_gap.numpy(), gnorm=gscale.numpy(), v=v.numpy(), gS=gS.numpy(), w=w.numpy(), info=info)


class GravityPPML(nn.Module):
    """Dynamic gravity: Poisson PML with importer-year effects concentrated out (a volume-weighted multinomial over
    suppliers), pair effects, lagged flow log1p(X/1000) with X in tonnes, the supplier's lagged log total exports and
    supplier-specific linear trends. weights='equal' gives the equally weighted variant GRAVeq."""
    def __init__(self, P, ridge=1e-2):
        super().__init__()
        self.P = P; self.ridge = ridge
        self.alpha = nn.Parameter(torch.zeros(P.N, P.K)); self.b1 = nn.Parameter(torch.tensor(0.5))
        self.b2 = nn.Parameter(torch.tensor(0.5)); self.trend = nn.Parameter(torch.zeros(P.K))
        self.avail = torch.tensor(P.avail)

    def forward_stack(self, st, override=None, key=None):
        v = self.alpha[None] + self.b1 * torch.log1p(st["X1"] / 1000.0) + self.b2 * st["ltot"][:, None, :] \
            + self.trend[None, None, :] * st["tt"][:, None, None]
        v = v.masked_fill((self.avail == 0)[None], -1e9)
        return torch.softmax(v, 2), None

    def penalty(self):
        return 0.5 * self.ridge * (self.alpha ** 2).sum()


def nll_of(model, st, W, key="train"):
    shat, _ = model.forward_stack(st, key=key)
    return -(W * (st["tgt"] * torch.log(shat.clamp_min(1e-12))).sum(2)).sum()


def fit_stack(model, st, weights="equal", steps=2500, lr=0.05, lbfgs_iter=300):
    """Adam (cosine decay) followed by an L-BFGS polish of the penalised negative log quasi-likelihood."""
    if weights == "equal": W = st["msk"]
    else:
        W = st["msk"] * st["vol"]; W = W / (W.sum() / st["msk"].sum())
    def objective():
        nll = nll_of(model, st, W); return nll + model.penalty(), nll
    opt = torch.optim.Adam(model.parameters(), lr=lr); hist = []
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=lr * 0.02)
    maxres = 0.0
    for it in range(steps):
        opt.zero_grad(); loss, nll = objective(); loss.backward(); opt.step(); sched.step()
        hist.append(float(loss)); maxres = max(maxres, getattr(model, "diag", {}).get("max_resid", 0.0))
    if lbfgs_iter:
        state = {k: v.clone() for k, v in model.state_dict().items()}
        with torch.no_grad(): before = float(objective()[0])
        opt2 = torch.optim.LBFGS(model.parameters(), lr=0.5, max_iter=lbfgs_iter, line_search_fn="strong_wolfe",
                                 tolerance_grad=1e-7, tolerance_change=1e-10, history_size=20)
        def cl():
            opt2.zero_grad(); l, _ = objective(); l.backward(); return l
        try: opt2.step(cl)
        except Exception: pass
        with torch.no_grad(): after = float(objective()[0])
        if not np.isfinite(after) or after > before: model.load_state_dict(state)
    loss, nll = objective()
    model.zero_grad(); loss.backward()
    gn = float(torch.cat([p.grad.reshape(-1) for p in model.parameters() if p.grad is not None]).abs().max())
    return dict(loss=float(loss), nll=float(nll), adam_steps=len(hist), hist=hist[::25], final_grad_maxabs=gn,
                max_fp_resid_training=maxres)


def predict_stack(model, P, years, override=None, h=1):
    st = stack_years(P, years, h)
    with torch.no_grad():
        shat, w = model.forward_stack(st, override)
    return {t: shat[y].numpy() for y, t in enumerate(st["years"])}


# ----------------------------------------------------------------------------- joint Laplace approximation
def _flat_params(mod):
    return [mod.alpha, mod.u, mod.mu_g, mod.rho, mod.theta, mod.leta, mod.lkappa, mod.zeta, mod.zeta_p]


def joint_hessian(mod, st, h=1e-4):
    """Hessian of the penalised objective at the fitted mode w.r.t. ALL parameters (pair effects, importer parameters,
    group means, commodity-level coefficients). The quasi-likelihood part is obtained by central finite differences of
    exact (implicit-function) gradients, exploiting that importer n's likelihood depends only on its own parameters
    and the shared coefficients (graph colouring: one direction per pair-effect column, per importer coordinate and per
    shared coefficient). The prior part is quadratic and obtained exactly by automatic differentiation."""
    P = mod.P; N, K = P.N, P.K; G = mod.mu_g.shape[0]
    plist = _flat_params(mod); sizes = [p.numel() for p in plist]; offs = np.cumsum([0] + sizes)
    D = int(offs[-1])
    ia = lambda n, k: offs[0] + n * K + k
    iu = lambda n, j: offs[1] + n * 4 + j
    glob = list(range(offs[3], D))  # rho, theta, leta, lkappa, zeta, zeta_p
    W = st["msk"]

    def grad_nll():
        mod.zero_grad(); l = nll_of(mod, st, W, key=None); l.backward()
        return torch.cat([(p.grad if p.grad is not None else torch.zeros_like(p)).reshape(-1) for p in plist]).detach().numpy().copy()

    base = [p.detach().clone() for p in plist]
    def setp(vec):
        with torch.no_grad():
            for p, b, a, z in zip(plist, base, offs[:-1], offs[1:]): p.copy_(b + torch.tensor(vec[a:z]).view_as(b))
    Hn = np.zeros((D, D))
    dirs = [("a", k) for k in range(K)] + [("u", j) for j in range(4)] + [("g", q) for q in glob]
    for kind, j in dirs:
        e = np.zeros(D)
        if kind == "a": e[[ia(n, j) for n in range(N)]] = h
        elif kind == "u": e[[iu(n, j) for n in range(N)]] = h
        else: e[j] = h
        setp(e); gp = grad_nll(); setp(-e); gm = grad_nll(); setp(np.zeros(D))
        col = (gp - gm) / (2 * h)
        if kind == "g":
            Hn[:, j] = col
        else:
            src = [ia(n, j) if kind == "a" else iu(n, j) for n in range(N)]
            for n in range(N):
                rows = [ia(n, k) for k in range(K)] + [iu(n, q) for q in range(4)]
                Hn[rows, src[n]] = col[rows]
    # shared-coefficient rows for importer columns from symmetry
    Hn[np.ix_(glob, range(offs[0], offs[2]))] = Hn[np.ix_(range(offs[0], offs[2]), glob)].T
    Hn = 0.5 * (Hn + Hn.T)
    # exact prior Hessian (quadratic): via autograd on the flattened vector
    vec0 = torch.cat([b.reshape(-1) for b in base]).clone().requires_grad_(True)
    def pen_of(vec):
        parts = [vec[a:z].view_as(b) for b, a, z in zip(base, offs[:-1], offs[1:])]
        alpha, u, mu = parts[0], parts[1], parts[2]
        pen = 0.5 * (alpha ** 2).sum() / mod.sig_alpha ** 2
        pen = pen + 0.5 * (((u - mu[mod.gid]) / mod.tau) ** 2).sum() + 0.5 * ((mu - mu.mean(0, keepdim=True)) ** 2).sum()
        return pen + 0.5 * (parts[5] ** 2 + parts[6] ** 2) / 4.0
    gpen = torch.autograd.grad(pen_of(vec0), vec0, create_graph=True)[0]
    Hp = np.zeros((D, D))
    for i in range(D):  # quadratic -> rows are cheap
        Hp[i] = torch.autograd.grad(gpen[i], vec0, retain_graph=True)[0].numpy()
    idx = dict(alpha=(offs[0], offs[1]), u=(offs[1], offs[2]), mu_g=(offs[2], offs[3]), glob=(offs[3], D), N=N, K=K, G=G, gid=P.gid.copy())
    return Hn, Hp, idx


def laplace_summary(Hn, Hp, idx, lik_weight=1.0):
    """marginal (joint-inverse) and conditional (importer-block) SDs; PD diagnostics."""
    H = lik_weight * Hn + Hp
    ev = np.linalg.eigvalsh(H)
    pd_ok = bool(ev.min() > 0)
    if pd_ok: C = np.linalg.inv(H)
    else:
        lam, V = np.linalg.eigh(H); lam = np.maximum(lam, 1e-8 * lam.max()); C = (V / lam) @ V.T
    sd = np.sqrt(np.clip(np.diag(C), 0, None))
    a, b = idx["u"]; N = idx["N"]
    u_sd = sd[a:b].reshape(N, 4)
    cond = np.zeros((N, 4))
    for n in range(N):
        blk = H[a + 4 * n:a + 4 * n + 4, a + 4 * n:a + 4 * n + 4]
        try: cond[n] = np.sqrt(np.clip(np.diag(np.linalg.inv(blk)), 0, None))
        except np.linalg.LinAlgError: cond[n] = np.nan
    ma, mb = idx["mu_g"]; ga, gb = idx["glob"]
    gid = idx["gid"]; dev = np.zeros((N, 4))
    for n in range(N):
        for j in range(4):
            i1 = a + 4 * n + j; i2 = ma + 4 * gid[n] + j
            dev[n, j] = np.sqrt(max(C[i1, i1] + C[i2, i2] - 2 * C[i1, i2], 0.0))
    return dict(u_sd=u_sd, u_sd_conditional=cond, dev_sd=dev, mu_sd=sd[ma:mb].reshape(-1, 4), glob_sd=sd[ga:gb], cov=C,
                min_eig=float(ev.min()), max_eig=float(ev.max()), n_neg_eig=int((ev <= 0).sum()), pd=pd_ok)


# ----------------------------------------------------------------------------- P0 persistence
def predict_persistence(P, years, h=1):
    out = {}
    for t in years:
        s = P.lag_shares(t, h) * P.avail
        s = np.maximum(s, FLOOR) * P.avail; out[t] = s / s.sum(1, keepdims=True)
    return out


# ----------------------------------------------------------------------------- P2 TERGM (MPLE)
def tergm_features(P, t, thr=0.01, h=1):
    s1 = P.lag_shares(t, h); s2 = P.lag_shares(t, h + 1)
    y1 = (s1 >= thr).astype(float); y2 = (s2 >= thr).astype(float)
    pop = np.log1p(y1.sum(0))[None, :].repeat(P.N, 0)
    deg = np.log1p(y1.sum(1))[:, None].repeat(P.K, 1)
    co = (y1 @ y1.T > 0).astype(float); np.fill_diagonal(co, 0)
    ncob = co.sum(1, keepdims=True)
    closure = (co @ y1) / np.maximum(ncob, 1)
    X = np.stack([np.ones_like(y1), y1, y2, y1 * y2, pop, deg, closure, P.logd - 8.5, P.CT, P.CL], -1)
    return X, y1, s1


def fit_tergm(P, years, thr=0.01, l2=1e-3, h=1):
    Xs, ys = [], []
    for t in years:
        if t - h - 1 < P.years[0]: continue
        b = P.yi[t]
        m = P.valid[:, b] & P.valid[:, P.yi[t - 1]] & P.valid[:, P.yi[t - h]]
        X, _, _ = tergm_features(P, t, thr, h)
        y = (np.nan_to_num(P.s[:, b]) >= thr).astype(float)
        mm = m[:, None] & (P.avail > 0)
        Xs.append(X[mm]); ys.append(y[mm])
    X = torch.tensor(np.concatenate(Xs)); y = torch.tensor(np.concatenate(ys))
    beta = torch.zeros(X.shape[1], requires_grad=True)
    opt = torch.optim.LBFGS([beta], max_iter=500, line_search_fn="strong_wolfe")
    def cl():
        opt.zero_grad(); l = Fnn.binary_cross_entropy_with_logits(X @ beta, y, reduction="sum") + l2 * (beta ** 2).sum(); l.backward(); return l
    opt.step(cl)
    return beta.detach().numpy()


def predict_tergm(P, beta, years, thr=0.01, h=1):
    out = {}
    for t in years:
        X, y1, s1 = tergm_features(P, t, thr, h)
        p = 1 / (1 + np.exp(-(X @ beta)))
        cust = (y1 > 0)
        mean_cust = np.where(cust.sum(0) > 0, (s1 * cust).sum(0) / np.maximum(cust.sum(0), 1), thr)
        mag = np.where(y1 > 0, s1, mean_cust[None, :])
        s = np.maximum(p * mag, FLOOR) * P.avail
        out[t] = s / s.sum(1, keepdims=True)
    return out


# ----------------------------------------------------------------------------- P3 GNN and variants
GNN_VARIANTS = {"GNN": "diag", "GNNfull": "full", "GNNnet": "none"}


class BipartiteGNN(nn.Module):
    """Two rounds of share-weighted message passing between importer and supplier nodes; an edge MLP gives next-year
    share logits. risk='diag': supplier nodes receive lagged anomalies, restriction indicators and the diagonal of the
    scaled covariance; 'full': additionally the supplier's full covariance row; 'none': no anomaly, restriction or
    covariance inputs (network-only ablation)."""
    def __init__(self, n_imp, n_sup, n_grp, h=32, drop=0.1, risk="diag"):
        super().__init__()
        self.risk = risk
        nx = {"diag": 9, "full": 9 + n_sup, "none": 2}[risk]
        self.emb_i = nn.Embedding(n_imp, 8); self.emb_k = nn.Embedding(n_sup, 8); self.emb_g = nn.Embedding(n_grp, 4)
        self.fi = nn.Sequential(nn.Linear(8 + 4 + 2, h), nn.ReLU())
        self.fk = nn.Sequential(nn.Linear(8 + nx, h), nn.ReLU())
        self.mi = nn.ModuleList([nn.Sequential(nn.Linear(2 * h, h), nn.ReLU()) for _ in range(2)])
        self.mk = nn.ModuleList([nn.Sequential(nn.Linear(2 * h, h), nn.ReLU()) for _ in range(2)])
        self.edge = nn.Sequential(nn.Linear(2 * h + 7, h), nn.ReLU(), nn.Dropout(drop), nn.Linear(h, h), nn.ReLU(), nn.Linear(h, 1))

    def forward(self, xi, xk, e, wadj, avail, gid):
        N, K = wadj.shape
        hi = self.fi(torch.cat([self.emb_i.weight, self.emb_g(gid), xi], 1))
        hk = self.fk(torch.cat([self.emb_k.weight, xk], 1))
        for l in range(2):
            mi = wadj @ hk; mk = (wadj.T @ hi) / wadj.sum(0).clamp_min(1e-6)[:, None]
            hi, hk = self.mi[l](torch.cat([hi, mi], 1)), self.mk[l](torch.cat([hk, mk], 1))
        z = torch.cat([hi[:, None, :].expand(N, K, -1), hk[None, :, :].expand(N, K, -1), e], 2)
        logit = self.edge(z)[:, :, 0] + torch.log(avail.clamp_min(1e-12))
        return torch.log_softmax(logit, 1)


def gnn_inputs(P, t, risk="diag", h=1):
    d = year_batch(P, t, h)
    s1 = d["slag"]; s2 = d["slag2"]
    vol1 = np.log1p(P.vol[:, P.yi[t - h]] / 1000.0)
    xi = np.stack([vol1 / 10, (s1 > 0.01).sum(1) / P.K], 1)
    if risk == "none":
        xk = np.stack([d["ltot"] / 15, d["luv"]], 1)
    else:
        xk = np.stack([d["ltot"] / 15, d["luv"], d["z1"], d["z2"], d["z3"], d["p1"], d["p2"], d["p3"], np.diag(d["SIG"])], 1)
        if risk == "full": xk = np.concatenate([xk, d["SIG"]], 1)
    e = np.stack([np.log(s1 + EPS_LAG), np.log(s2 + EPS_LAG), (P.logd - 8.5), P.CT, P.CL,
                  np.log(d["peer"] + EPS_LAG), (s1 > 0.01).astype(float)], -1)
    T = lambda x: torch.tensor(x, dtype=torch.float32)
    return T(xi), T(xk), T(e), T(s1 + 1e-3), T(P.avail)


def fit_gnn(P, train_years, val_years=None, h=32, wd=1e-4, epochs=400, lr=3e-3, seed=0, device="cpu", patience=40, risk="diag", hz=1):
    torch.manual_seed(seed); np.random.seed(seed)
    net = BipartiteGNN(P.N, P.K, len(P.groups), h=h, risk=risk).to(device).float()
    opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=wd)
    gid = torch.tensor(P.gid, dtype=torch.long, device=device)
    def pack(years):
        out = []
        for t in years:
            if t - hz - 1 < P.years[0]: continue
            b = P.yi[t]; m = P.valid[:, b] & P.valid[:, P.yi[t - 1]] & P.valid[:, P.yi[t - hz]]
            if m.sum() == 0: continue
            xs = [x.to(device) for x in gnn_inputs(P, t, risk, hz)]
            out.append((xs, torch.tensor(np.nan_to_num(P.s[:, b]), dtype=torch.float32, device=device),
                        torch.tensor(m.astype(np.float32), device=device)))
        return out
    tr = pack(train_years); va = pack(val_years) if val_years else None
    best, best_state, best_ep, bad = np.inf, None, 0, 0; hist = []
    for ep in range(epochs):
        net.train(); opt.zero_grad(); loss = 0.0
        for xs, s, m in tr:
            lp = net(*xs, gid); loss = loss - ((s * lp).sum(1) * m).sum() / m.sum()
        (loss / len(tr)).backward(); opt.step()
        if va is not None:
            net.eval()
            with torch.no_grad():
                vl = 0.0; cnt = 0.0
                for xs, s, m in va:
                    lp = net(*xs, gid); ent = torch.where(s > 0, s * torch.log(s.clamp_min(1e-12)), torch.zeros_like(s)).sum(1)
                    vl += float(((ent - (s * lp).sum(1)) * m).sum()); cnt += float(m.sum())
            vl /= cnt; hist.append(vl)
            if vl < best - 1e-5: best, best_ep, bad = vl, ep, 0; best_state = {k: v.clone() for k, v in net.state_dict().items()}
            else:
                bad += 1
                if bad > patience: break
    if best_state is not None: net.load_state_dict(best_state)
    return net, dict(best_val=best, best_epoch=best_ep, hist=hist)


def predict_gnn(nets, P, years, device="cpu", risk="diag", h=1):
    gid = torch.tensor(P.gid, dtype=torch.long, device=device); out = {}
    with torch.no_grad():
        for t in years:
            xs = [x.to(device) for x in gnn_inputs(P, t, risk, h)]
            ps = [torch.exp(net.eval()(*xs, gid)).double().cpu().numpy() for net in nets]
            out[t] = np.mean(ps, 0)
    return out
