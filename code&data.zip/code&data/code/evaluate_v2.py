"""Evaluation of the forecast contest (registered rules + revision analyses). Run from the package root:

  python code/evaluate_v2.py v2   evaluates the corrected v2 forecasts in out/post (results/v2/...)

Sign convention used everywhere: A = mean loss(comparator) - mean loss(BR); A > 0 means BR forecasts better.
"""
import os, sys, json, warnings, numpy as np, pandas as pd
warnings.simplefilter("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
from models import Panel, FLOOR, kl_loss, hellinger
COMMODS = ["wheat", "maize", "rice", "soybeans"]
WIN = {"W1": [2014, 2015, 2016], "W2": [2020, 2021], "W3": [2022, 2023], "T": [2017, 2018, 2019], "X2024": [2024]}
WOF = {t: w for w, ts in WIN.items() for t in ts}
SHOCK = ["W1", "W2", "W3"]
B = 2000


def load_cases(version, h=1, floor=FLOOR, avail_floor=False):
    if version != "v2": raise ValueError("This release supports the corrected v2 analysis only.")
    rows = []
    for c in COMMODS:
        P = Panel(f"data/arrays/arrays_{c}_full.npz", cutoff=2013)
        z = np.load(f"out/post/pred_{c}.npz"); n, t, s = z[f"n_h{h}"], z[f"t_h{h}"], z[f"s_h{h}"]
        preds = {}
        for k in z.files:
            if k.startswith("shat_") and k.endswith(f"_h{h}"):
                m = k[5:-3]; m = {"BR_main": "BR", "BR0_main": "BR0", "BR_h2": "BR", "BR0_h2": "BR0"}.get(m, m); preds[m] = z[k]
        av = P.avail[n]
        d = pd.DataFrame(dict(c=c, n=n, t=t, iso=[P.I[i] for i in n], inc=[P.inc[i] for i in n], reg=[P.reg[i] for i in n]))
        slag = np.array([P.lag_shares(tt, 1)[nn] for nn, tt in zip(n, t)])
        a1 = [P.ai[tt - 1] for tt in t]
        hit = np.array([(np.nan_to_num(P.Z[:, a]) < -1.0) | (P.POL[:, a] > 0) for a in a1])
        d["expo"] = (slag * hit).sum(1); d["rewire"] = 0.5 * np.abs(s - slag).sum(1)
        d["vol"] = [P.vol[nn, P.yi[tt]] for nn, tt in zip(n, t)]
        d["row_share"] = s[:, -1]
        entry = (slag <= 0) & (s > 0); entry[:, -1] = False
        if "PERSIST" in preds:  # stored persistence forecasts were floored at 1e-4; recompute from raw lagged shares so the floor is set only by kl_loss
            sl_h = np.array([P.lag_shares(tt, h)[nn] for nn, tt in zip(n, t)]) * av
            preds["PERSIST"] = sl_h / np.maximum(sl_h.sum(1, keepdims=True), 1e-300)
        d["entry_share"] = (s * entry).sum(1)
        for m, sh in preds.items():
            kw = dict(floor=floor, avail=av if avail_floor else None)
            d[m] = kl_loss(s, sh, **kw); d[m + "_hel"] = hellinger(s, sh, **kw)
            # decomposition of KL into continuing links, entries and the rest-of-world category
            a = av if avail_floor else np.ones_like(sh)
            q = np.where(a > 0, np.maximum(sh, floor), 0.0); q = q / q.sum(1, keepdims=True)
            term = np.where(s > 0, s * np.log(np.where(s > 0, s, 1) / np.where(s > 0, q, 1)), 0.0)
            cont = (slag > 0) & (s > 0); cont[:, -1] = False
            d[m + "_klcont"] = (term * cont).sum(1); d[m + "_klentry"] = (term * entry).sum(1); d[m + "_klrow"] = term[:, -1]
        rows.append(d)
    df = pd.concat(rows, ignore_index=True)
    df = df.sort_values(["c", "n", "t"]).reset_index(drop=True)  # same order as the registered evaluation (pivot index)
    df["win"] = df.t.map(WOF); df["cl"] = df.c + "_" + df.n.astype(str)
    return df


# ------------------------------------------------------------------ resampling schemes
def draws_cluster(df, key, seed=20131231):
    """registered scheme: clusters = importer-commodity histories (key='cl'); also used with key='iso' (country)."""
    cls = df[key].unique(); rng = np.random.default_rng(seed)
    idx = {k: np.where(df[key].values == k)[0] for k in cls}
    return [np.concatenate([idx[k] for k in rng.choice(cls, len(cls))]) for _ in range(B)]


def weights_pigeonhole(df, seed=3):
    """Owen (2007) pigeonhole bootstrap: countries and years resampled independently; case weight = product of counts."""
    rng = np.random.default_rng(seed)
    cs = df.iso.unique(); ys = df.t.unique()
    ci = pd.Index(cs).get_indexer(df.iso); yi = pd.Index(ys).get_indexer(df.t)
    out = []
    for _ in range(B):
        wc = np.bincount(rng.integers(0, len(cs), len(cs)), minlength=len(cs)); wy = np.bincount(rng.integers(0, len(ys), len(ys)), minlength=len(ys))
        out.append(wc[ci] * wy[yi])
    return out


def contrast(df, comp, ref, scheme, cols=None):
    """A_w = mean loss(comp) - mean loss(ref) for pooled shocks S, tranquil T, S-T and each window"""
    d = (df[comp] - df[ref]).values; w = df.win.values
    masks = {"S": np.isin(w, SHOCK), "T": w == "T", "W1": w == "W1", "W2": w == "W2", "W3": w == "W3", "X2024": w == "X2024"}
    def f(wt):
        out = {k: (np.sum(d * wt * m) / np.sum(wt * m) if np.sum(wt * m) > 0 else np.nan) for k, m in masks.items()}
        out["S_minus_T"] = out["S"] - out["T"]; return out
    est = f(np.ones(len(d)))
    if scheme[0] == "idx":
        bs = []
        for ix in scheme[1]:
            wt = np.bincount(ix, minlength=len(d)).astype(float); bs.append(f(wt))
    else:
        bs = [f(wt.astype(float)) for wt in scheme[1]]
    bs = pd.DataFrame(bs)
    ci = {k: [float(np.nanpercentile(bs[k], 2.5)), float(np.nanpercentile(bs[k], 97.5))] for k in est}
    ci90 = {k: [float(np.nanpercentile(bs[k], 5)), float(np.nanpercentile(bs[k], 95))] for k in est}
    return dict(est={k: float(v) for k, v in est.items()}, ci=ci, ci90=ci90)


def h1_rules(a, g):
    crit_a = a["ci"]["S"][0] > 0; crit_b = a["ci"]["S_minus_T"][0] > 0
    crit_c = (a["ci"]["T"][0] <= 0 <= a["ci"]["T"][1]) or (a["est"]["T"] <= 0.25 * a["est"]["S"])
    fail_gnn = not (g["ci"]["S"][0] > 0)
    return dict(a_shock_adv_positive=bool(crit_a), b_shock_minus_tranquil_positive=bool(crit_b), c_tranquil_small=bool(crit_c),
                c_note="registered rule; satisfied mechanically when both advantages are negative" if (a["est"]["T"] < 0 and a["est"]["S"] < 0 and crit_c) else "",
                gnn_not_beaten=bool(fail_gnn), passed=bool(crit_a and crit_b and crit_c and not fail_gnn))


def tost(r, key, margins=(0.005, 0.01, 0.02)):
    lo, hi = r["ci90"][key]
    return {str(m): bool(lo > -m and hi < m) for m in margins}


def evaluate(version):
    out = f"results/{version}"; os.makedirs(out, exist_ok=True)
    df = load_cases(version); df.to_csv(f"{out}/contest_cases.csv.gz", index=False)
    base = ["BR", "BR0", "PERSIST", "GRAV", "TERGM", "GNN"]
    extra = [m for m in ["GRAVeq", "GNNfull", "GNNnet"] if m in df]
    schemes = {"importer_commodity": ("idx", draws_cluster(df, "cl")), "country": ("idx", draws_cluster(df, "iso", seed=5)),
               "country_x_year": ("w", weights_pigeonhole(df))}
    res = dict(n_cases=int(len(df)), n_clusters=int(df.cl.nunique()), n_countries=int(df.iso.nunique()),
               n_by_win=df.win.value_counts().to_dict())
    res["mean_kl"] = df.groupby("win")[base + extra].mean().to_dict()
    res["mean_hel"] = df.groupby("win")[[m + "_hel" for m in base + extra]].mean().to_dict()
    res["mean_kl_by_c"] = {c: df[df.c == c].groupby("win")[base + extra].mean().to_dict() for c in COMMODS}
    res["adv"] = {}
    for comp in base[1:] + extra:
        for loss, sfx in [("kl", ""), ("hel", "_hel")]:
            for sn, sc in schemes.items():
                if loss == "hel" and sn != "importer_commodity" and comp not in ("GNN", "BR0", "PERSIST"): continue
                res["adv"][f"{comp}|{loss}|{sn}"] = contrast(df, comp + sfx, "BR" + sfx, sc)
    reg = lambda comp, loss="kl": res["adv"][f"{comp}|{loss}|importer_commodity"]
    pstar = "GNN"
    res["H1_registered"] = h1_rules(reg(pstar), reg("GNN"))
    res["H1b_registered"] = dict(est=reg("BR0")["est"]["S"], ci=reg("BR0")["ci"]["S"], passed=bool(reg("BR0")["ci"]["S"][0] > 0))
    res["TOST_posthoc"] = {f"{comp}|{key}|{sn}": tost(res["adv"][f"{comp}|kl|{sn}"], key)
                           for comp in ["GNN", "BR0"] for key in ["S_minus_T", "S", "T"] for sn in schemes}
    # leave-one-window-out and annual contrasts (registered resampling)
    res["lowo"] = {}
    for drop in SHOCK:
        sub = df[df.win != drop].reset_index(drop=True)
        res["lowo"][drop] = {comp: contrast(sub, comp, "BR", ("idx", draws_cluster(sub, "cl", seed=11)))["est"] | {"ci_S_minus_T": contrast(sub, comp, "BR", ("idx", draws_cluster(sub, "cl", seed=11)))["ci"]["S_minus_T"]} for comp in ["GNN", "BR0"]}
    ann = []
    for t in sorted(df.t.unique()):
        sub = df[df.t == t].reset_index(drop=True); dr = draws_cluster(sub, "iso", seed=int(t))
        for comp in ["GNN", "BR0", "PERSIST", "GRAV", "TERGM"]:
            d = (sub[comp] - sub["BR"]).values
            bs = [d[ix].mean() for ix in dr]
            ann.append(dict(t=int(t), comp=comp, est=float(d.mean()), lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)), n=int(len(sub))))
    pd.DataFrame(ann).to_csv(f"{out}/annual_contrasts.csv", index=False)
    # floor sensitivity (flooring on available suppliers only)
    fl = {}
    for f in [1e-3, 1e-4, 1e-5, 1e-6]:
        d2 = load_cases(version, floor=f, avail_floor=True)
        sch = ("idx", draws_cluster(d2, "cl"))
        fl[str(f)] = {comp: contrast(d2, comp, "BR", sch) for comp in ["GNN", "BR0", "PERSIST"]}
        fl[str(f)]["mean_S"] = d2[d2.win.isin(SHOCK)][base].mean().to_dict()
    res["floor_sensitivity"] = fl
    # KL decomposition (S windows)
    S = df[df.win.isin(SHOCK)]
    res["kl_decomposition_S"] = {m: dict(continuing=float(S[m + "_klcont"].mean()), entry=float(S[m + "_klentry"].mean()), row=float(S[m + "_klrow"].mean()),
                                         other=float((S[m] - S[m + "_klcont"] - S[m + "_klentry"] - S[m + "_klrow"]).mean())) for m in base + extra}
    res["entry_cases_share"] = float((df.entry_share > 0).mean()); res["entry_mass_mean"] = float(df.entry_share.mean())
    # volume-weighted contest
    w = df.vol.values
    res["volume_weighted_S"] = {m: float(np.sum(S[m] * S.vol) / S.vol.sum()) for m in base + extra}
    res["volume_weighted_T"] = {m: float(np.sum(df[df.win == "T"][m] * df[df.win == "T"].vol) / df[df.win == "T"].vol.sum()) for m in base + extra}
    # exploratory splits
    exposed = (df.expo >= 0.10).values; q = df.rewire.quantile(0.8); high = (df.rewire >= q).values
    def split(comp, ref, m1, sn="country"):
        d = (df[comp] - df[ref]).values; dr = draws_cluster(df, "iso", seed=17)
        e = (d[m1].mean(), d[~m1].mean()); bs = []
        for ix in dr:
            wt = np.bincount(ix, minlength=len(d)).astype(float)
            bs.append(((d * wt * m1).sum() / (wt * m1).sum(), (d * wt * ~m1).sum() / (wt * ~m1).sum()))
        bs = np.array(bs)
        return dict(a=float(e[0]), a_ci=np.percentile(bs[:, 0], [2.5, 97.5]).tolist(), b=float(e[1]), b_ci=np.percentile(bs[:, 1], [2.5, 97.5]).tolist(),
                    diff=float(e[0] - e[1]), diff_ci=np.percentile(bs[:, 0] - bs[:, 1], [2.5, 97.5]).tolist(), n_a=int(m1.sum()), n_b=int((~m1).sum()))
    res["exposure"] = {comp: split(comp, "BR", exposed) for comp in ["GNN", "BR0", "PERSIST", "GRAV", "TERGM"]}
    res["rewire_outcome_defined"] = {comp: split(comp, "BR", high) for comp in ["GNN", "BR0", "PERSIST", "GRAV", "TERGM"]}
    res["rewire_q80"] = float(q)
    if "GNNnet" in df:
        sh = np.isin(df.win.values, SHOCK); keep = sh | (df.win.values == "T")
        sub = df[keep].reset_index(drop=True)
        d = (sub["GNNnet"] - sub["GNN"]).values; m1 = np.isin(sub.win.values, SHOCK); dr = draws_cluster(sub, "iso", seed=19)
        bs = np.array([[(d[ix][m1[ix]]).mean(), (d[ix][~m1[ix]]).mean()] for ix in dr])
        res["gnnnet_minus_gnn"] = dict(S=float(d[m1].mean()), T=float(d[~m1].mean()), S_ci=np.percentile(bs[:, 0], [2.5, 97.5]).tolist(),
                                       T_ci=np.percentile(bs[:, 1], [2.5, 97.5]).tolist(), diff=float(d[m1].mean() - d[~m1].mean()),
                                       diff_ci=np.percentile(bs[:, 0] - bs[:, 1], [2.5, 97.5]).tolist())
    # exposure regression with commodity x year fixed effects (exploratory), country-clustered SE
    try:
        X = pd.get_dummies(df.c + "_" + df.t.astype(str), drop_first=False).astype(float)
        X.insert(0, "exposed", exposed.astype(float)); y = (df["GNN"] - df["BR"]).values
        Xv = X.values; beta, *_ = np.linalg.lstsq(Xv, y, rcond=None); e = y - Xv @ beta
        XtX = np.linalg.pinv(Xv.T @ Xv); meat = np.zeros_like(XtX)
        for g in df.iso.unique():
            ix = (df.iso == g).values; sg = Xv[ix].T @ e[ix]; meat += np.outer(sg, sg)
        V = XtX @ meat @ XtX
        res["exposure_regression_FE"] = dict(beta=float(beta[0]), se=float(np.sqrt(V[0, 0])), n=int(len(y)), n_clusters=int(df.iso.nunique()))
    except Exception as ex:
        res["exposure_regression_FE"] = str(ex)
    res["coverage"] = dict(row_share_mean=float(df.row_share.mean()), row_share_S=float(S.row_share.mean()))
    # GNN seed variation
    seeds = [m for m in df if m.startswith("GNNseed") and not m.endswith(("_hel", "_klcont", "_klentry", "_klrow"))]
    if seeds:
        res["gnn_seeds_S"] = {m: float(S[m].mean()) for m in seeds}
        res["gnn_seed_adv_S"] = {m: contrast(df, m, "BR", schemes["importer_commodity"])["est"]["S"] for m in seeds}
    json.dump(res, open(f"{out}/contest_results.json", "w"), indent=1)
    return res, df


def evaluate_variants():
    """robustness variants and h=2 contest (v2 only)"""
    out = "results/v2"; rows = []
    variants = ["main", "s01", "s09", "cent", "sevdur", "legal", "sign", "gpeer", "tau2", "start1", "start2"]
    base = []
    for c in COMMODS:
        P = Panel(f"data/arrays/arrays_{c}_full.npz", cutoff=2013); z = np.load(f"out/post/pred_{c}.npz")
        d = pd.DataFrame(dict(c=c, n=z["n_h1"], t=z["t_h1"])); s = z["s_h1"]
        for k in z.files:
            if k.startswith("shat_") and k.endswith("_h1"): d[k[5:-3]] = kl_loss(s, z[k])
        base.append(d)
    df = pd.concat(base, ignore_index=True).sort_values(["c", "n", "t"]).reset_index(drop=True)
    df["win"] = df.t.map(WOF); df["cl"] = df.c + "_" + df.n.astype(str)
    sch = ("idx", draws_cluster(df, "cl"))
    for v in variants:
        brv = f"BR_{v}"; br0v = f"BR0_{v}" if f"BR0_{v}" in df else "BR0_main"
        r1 = contrast(df.assign(BRx=df[brv]), "GNN", "BRx", sch); r2 = contrast(df.assign(BRx=df[brv]), br0v, "BRx", sch)
        rows.append(dict(variant=v, BR_S=float(df[df.win.isin(SHOCK)][brv].mean()), BR_T=float(df[df.win == "T"][brv].mean()),
                         GNN_S=r1["est"]["S"], GNN_S_lo=r1["ci"]["S"][0], GNN_S_hi=r1["ci"]["S"][1],
                         GNN_SmT=r1["est"]["S_minus_T"], GNN_SmT_lo=r1["ci"]["S_minus_T"][0], GNN_SmT_hi=r1["ci"]["S_minus_T"][1],
                         BR0=br0v, BR0_S=r2["est"]["S"], BR0_S_lo=r2["ci"]["S"][0], BR0_S_hi=r2["ci"]["S"][1]))
    pd.DataFrame(rows).to_csv(f"{out}/robustness_variants.csv", index=False)
    # h = 2 (information through t-2)
    d2 = load_cases("v2", h=2); sch2 = ("idx", draws_cluster(d2, "cl"))
    h2 = dict(n=int(len(d2)), mean_kl=d2.groupby("win")[["BR", "BR0", "PERSIST", "GRAV", "TERGM", "GNN"]].mean().to_dict())
    h2["adv"] = {comp: contrast(d2, comp, "BR", sch2) for comp in ["BR0", "PERSIST", "GRAV", "TERGM", "GNN"]}
    h2["H1_registered_rules"] = h1_rules(h2["adv"]["GNN"], h2["adv"]["GNN"])
    json.dump(h2, open(f"{out}/contest_h2.json", "w"), indent=1)
    return rows, h2


if __name__ == "__main__":
    v = sys.argv[1] if len(sys.argv) > 1 else "v2"
    res, df = evaluate(v)
    print(json.dumps(res["H1_registered"]), json.dumps(res["H1b_registered"]))
    if v == "v2": evaluate_variants()
