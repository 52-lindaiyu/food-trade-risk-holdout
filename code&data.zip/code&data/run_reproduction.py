"""Run the corrected food-trade analysis with prepared inputs. Use --dry-run to preview."""
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
STAGES=['risk','dev','select','fit','post','evaluate','analyse']
COMMODS=['wheat','maize','rice','soybeans']
SPECS=['dev','pre','full']+[v+'_'+period for v in ['s01','s09','cent','sevdur','legal'] for period in ['pre','full']]

def required_inputs():
    paths=[ROOT/'config/config_v2.json',ROOT/'data/teleconnections_annual.csv']
    paths.extend(ROOT/f'data/arrays/arrays_{c}_{s}.npz' for c in COMMODS for s in SPECS)
    missing=[str(p.relative_to(ROOT)) for p in paths if not p.is_file()]
    if missing:raise FileNotFoundError('Missing supplied input(s): '+', '.join(missing))

def recompute_risk():
    """Apply the original reference-covariance routine to the supplied sufficient inputs."""
    import numpy as np
    import pandas as pd
    spec=importlib.util.spec_from_file_location('risk_landscape',ROOT/'code/03_risk_landscape.py')
    risk=importlib.util.module_from_spec(spec);spec.loader.exec_module(risk)
    tele=pd.read_csv(ROOT/'data/teleconnections_annual.csv',index_col=0)
    dest=ROOT/'out/risk';dest.mkdir(parents=True,exist_ok=True)
    for c in COMMODS:
        for s in SPECS:
            with np.load(ROOT/f'data/arrays/arrays_{c}_{s}.npz',allow_pickle=False) as z:
                factors=tele.reindex(z['ally'])[risk.TELE_COLS].to_numpy()
                policy_variance=0.01 if s.startswith('s01_') else 0.09 if s.startswith('s09_') else 0.04
                cov=np.stack([risk.sigma_t(z['A'],factors,z['POL'],z['ally'],int(t),sigma2_pol=policy_variance,centered=s.startswith('cent_'))[0] for t in z['years']])
                np.savez_compressed(dest/f'SIG_{c}_{s}.npz',years=z['years'],SIG=cov)
    print('Reference covariances written to out/risk/. Supplied model inputs are unchanged.',flush=True)

def require_fits():
    # Derive the complete fitted-file set from the original task definitions.
    sys.path.insert(0,str(ROOT/'code'))
    import run
    missing=[]
    for task in run.fit_tasks():
        m,_,_=task;name=run.tname(task)
        names=[name+'.json',name+('_beta.npy' if m=='TERGM' else '.pt')]
        missing.extend(name for name in names if not (ROOT/'out/fit'/name).is_file())
    if missing:raise FileNotFoundError('Run the fit stage first. Missing fitted file(s): '+', '.join(missing[:8])+(' ...' if len(missing)>8 else ''))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--from',dest='start',choices=STAGES)
    parser.add_argument('--to',dest='stop',choices=STAGES)
    parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    if args.start is None and args.stop is None:parser.print_help();return
    if args.start is None:parser.error('--from is required with --to')
    if args.workers<1:parser.error('--workers must be positive')
    first,last=STAGES.index(args.start),STAGES.index(args.stop or args.start)
    if first>last:parser.error('--from must not follow --to')
    commands={
        'dev':[[sys.executable,'code/run.py','dev',str(args.workers)]],
        'select':[[sys.executable,'code/run.py','select']],
        'fit':[[sys.executable,'code/run.py','fit',str(args.workers)]],
        'post':[[sys.executable,'code/run.py','post',str(args.workers)]],
        'evaluate':[[sys.executable,'code/evaluate_v2.py','v2']],
        'analyse':[[sys.executable,'code/analyse_identification.py']],
    }
    required_inputs()
    for stage in STAGES[first:last+1]:
        print('['+stage+']',flush=True)
        if stage=='risk':
            if args.dry_run:print('Recompute reference covariances from the supplied anomalies, factors and policy indicators.')
            else:recompute_risk()
            continue
        if stage=='post' and not args.dry_run:require_fits()
        for cmd in commands[stage]:
            print(subprocess.list2cmdline(cmd[1:]),flush=True)
            if not args.dry_run:subprocess.run(cmd,cwd=ROOT,check=True)
    if args.dry_run:print('Plan only; no numerical computation performed.')

if __name__=='__main__':main()
