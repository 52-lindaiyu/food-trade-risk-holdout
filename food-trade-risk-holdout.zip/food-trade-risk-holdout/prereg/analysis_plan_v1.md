# Analysis plan v1 (frozen before any post-2013 trade outcome is examined)

Title of study: Revealed risk governance in staple-food import portfolios and a Lucas-critique test of forecasting models.

Status at freezing. Bilateral trade flows for 1986-2013 have been extracted into the working file. All trade rows for 2014 onwards have been written to a sealed file whose SHA-256 digest is recorded in `seal_log.json`; only the list of years present in that file and its byte size have been read. Production, yield, teleconnection-index, distance and classification data are exogenous covariates and are available for all years. Export-restriction episodes for 2014-2023 were coded from the published literature before unsealing. The analysts have general background knowledge of post-2013 events (for example the 2022 invasion of Ukraine), which motivated the pre-specified window labels below; they have not examined post-2013 bilateral trade outcomes for the four commodities.

## 1. Data and units

Commodities: wheat (FAOSTAT item 15), maize (56), rice in milled equivalent (items 27, 29, 31, 32; paddy multiplied by 0.67 and husked by 0.80 unless the aggregate item 30 is populated, in which case item 30 is used), and soybeans (236). Unit of analysis: importer i, commodity c, year t. Bilateral quantities: importer-reported import quantity, replaced by the partner-reported export quantity when the importer report is missing. Supplier set S_c: exporters with at least 1% of world export quantity of commodity c in any year 1986-2013, capped at the 15 largest by cumulative 1986-2013 exports, plus one aggregate "rest of world" (ROW) supplier. Importer set I_c: countries with mean imports of commodity c of at least 50,000 t per year over 2004-2013 and positive imports in at least 15 of the years 1986-2013. Shares s_ijt are quantity shares over S_c. Importer-years with zero total imports are dropped.

## 2. Exogenous risk landscape (computed in real time)

For each supplier j and year t, the yield anomaly z_js (s <= t-1) is log yield minus a linear trend fitted to the 15 preceding years, standardised by the real-time standard deviation of past anomalies. ROW uses the production-weighted anomaly of all other producers. The true supplier covariance Sigma_t uses only information up to t-1: a teleconnection factor component B Cov(f) B' with loadings from ridge regressions of z on five seasonal indices (Nino3.4 DJF and JAS, Dipole Mode Index SON of t and t-1, NAO DJFM), plus a Ledoit-Wolf-shrunk residual covariance, plus a policy-risk component equal to the real-time frequency of coded export-restriction years on the diagonal. Covariance windows use the 25 most recent years.

## 3. Behavioural model (revealed risk governance, BR)

Importer i chooses shares w on the simplex. Perceived covariance: Sigma~_it = D_i (Sigma_t + eta diag(M_it)) D_i with D_i = diag(exp(-delta_i dbar_ij)), dbar_ij the great-circle distance in units of 10,000 km, and memory term M_ijt = sum_{s<=t-1} phi_i^(t-1-s) (max(0,-z_js)^2 + kappa P_js), where P_js indicates a coded export restriction. The optimal portfolio solves the entropy-regularised mean-variance problem whose first-order condition is the fixed point w_j proportional to exp(alpha_ij + rho log(s_ij,t-1 + 0.005) - theta log p_j,t-1 - gamma_i (Sigma~_it w)_j), with p the supplier's export unit value. Peer weight: predicted shares s^_it = (1-omega_i) w*_it + omega_i sbar_peer(i),t-1, with peers the other importers in the same World Bank region weighted by import volume. Importer parameters (gamma_i, delta_i, phi_i, omega_i) receive a hierarchical Gaussian prior on transformed scales with group means by World Bank region x income group; commodity-level parameters are (rho, theta, eta, kappa) and pair effects alpha_ij carry a ridge prior. Estimation is maximum a posteriori under the fractional multinomial log-likelihood sum_j s_ijt log s^_ijt. Identification diagnostics: curvature of the profile likelihood and posterior standard deviations from the Laplace approximation; parameters whose posterior SD exceeds the prior SD by more than 0.8 are flagged weakly identified.

Ablation (secondary): BR with gamma_i = 0 ("dynamic logit"), which removes all risk terms while keeping the functional form.

## 4. Phenomenological competitors

P0 persistence: s^_t = s_t-1. P1 dynamic structural gravity estimated by Poisson pseudo-maximum likelihood with pair fixed effects, importer-year effects (absorbed by normalising within importer), lagged log bilateral flow, the supplier's lagged log total exports and supplier-specific linear trends. P2 temporal exponential random graph model estimated by maximum pseudo-likelihood on links s_ijt >= 0.01 with stability, two-year memory, supplier popularity, importer degree, shared-partner (four-cycle) closure, distance and contiguity terms; shares are formed as link probability times the lagged share (or the supplier's mean customer share for currently absent links) and renormalised. P3 graph neural network: bipartite message-passing network trained to predict next-year share logits from the previous two snapshots, node and edge covariates; ensemble of five seeds.

## 5. Contest design

All parameters of all models are estimated on years <= 2013 and then frozen. Forecasts for year t use observed information up to t-1 (one-step-ahead, parameters fixed). Evaluation years 2014-2023 (and 2024 as exploratory if present). Pre-specified windows: shock windows W1 = 2014-2016, W2 = 2020-2021, W3 = 2022-2023; tranquil window T = 2017-2019. Loss: Kullback-Leibler divergence KL(s_it || s^_it) per importer-commodity-year, with s^ floored at 1e-4 and renormalised. Secondary loss: Hellinger distance.

Development stage (allowed before unsealing): models are trained on <= 2005 and validated on 2006-2013 to select hyperparameters (ridge strengths, GNN width and epochs, TERGM threshold) and to verify convergence. The selected hyperparameters are recorded in a hash-sealed amendment before unsealing.

## 6. Hypotheses and decision rules

Strongest phenomenological competitor P*: the competitor among P0-P3 with the lowest mean loss in the 2006-2013 development validation.

H1 (Lucas test). Advantage A_w = mean loss(P*) - mean loss(BR) in window w. The test is passed if all three hold: (a) the pooled shock-window advantage A_S (W1, W2, W3 pooled) is positive with a 95% importer-cluster bootstrap interval excluding zero; (b) the difference A_S - A_T is positive with a 95% interval excluding zero; (c) the tranquil advantage A_T is small, defined as its 95% interval including zero or A_T <= 0.25 A_S. The test fails if BR's pooled shock-window loss is not lower than that of the graph neural network (P3) with a 95% interval excluding zero. Bootstrap: 2,000 resamples of importer-commodity clusters.

H1b (attribution). The shock-window advantage of BR over its gamma = 0 ablation is positive.

H2 (recoverability). On synthetic data generated from the fitted BR model with known parameters, group-level means of the four perception parameters are recovered with absolute bias below 25% of their prior SD and with 80-95% nominal coverage between 70% and 98%.

H3 (descriptive). Estimated distance discounts are positive on average (delta > 0) and estimated memory half-lives are shorter than the median recurrence interval of supplier shocks.

All results are reported regardless of direction. Analyses not listed here are labelled exploratory.
