# Amendment A to analysis plan v1 (frozen before unsealing post-2013 trade data)

Plan v1 SHA-256: 5a280350116281a5db3fbb82e3e2bfd2608de88780ee5eb4c13566c96d085e67.
Sealed post-2013 trade file SHA-256: 28c630fc4c57e710fe308b3e4e503bc082735c8fa28b09d8cd3fce6c6690a690 (unopened at the time of this amendment).
Frozen at (UTC): 2026-10-09T11:34:33.540875Z

## A1. Implementation details and development-stage changes (all decided with data up to 2013 only)

A1.1 Risk landscape. The true covariance Sigma_t is computed on unstandardised real-time log-yield anomalies (log units); the policy-risk diagonal equals the real-time frequency of coded restriction years multiplied by 0.04 (a restriction year treated as a 20% supply loss). Successor states Ukraine and Kazakhstan inherit the USSR yield series before 1992; predecessor entities are harmonised (USSR to Russia, Belgium-Luxembourg to Belgium, Czechoslovakia to Czechia, Yugoslavia and Serbia-Montenegro to Serbia, Ethiopia PDR to Ethiopia, former Sudan to Sudan). Suppliers whose mean 1986-2013 production is below half their mean exports (re-export hubs: Belgium for rice and the Netherlands for soybeans) are assigned the rest-of-world anomaly. Rice uses FAOSTAT item 30 (milled equivalent), which is populated.

A1.2 Behavioural model. (i) Two physical-availability controls common to all importers were added to the utility: zeta * z_(j,t-1) and -zeta_p * P_(j,t-1). They separate the mechanical effect of a shortfall or restriction on next-year availability from risk perception; the memory term must explain behaviour beyond them. (ii) Standardised shortfalls entering the memory term are capped at 3 SD. (iii) The fixed point is solved by damped mirror descent with an importer-specific step min(0.7, 1/(1 + gamma_i * g_i)), where g_i is the Gershgorin bound of the perceived covariance, for 60 iterations; development rounds 1 and 2 showed that a fixed step did not converge for large gamma and produced unstable forecasts. (iv) Hierarchical prior: transformed importer parameters u_i ~ N(mu_g, diag(tau)) with tau = s * (1, 2, 1, 1); group means mu_g ~ N(mean of mu, 1); pair effects alpha_ij ~ N(0, sigma_alpha^2); log eta and log kappa ~ N(0, 4). The scale s and sigma_alpha were selected on development validation (train 1988-2005, validate 2006-2013) from s in {0.25, 0.5, 1} and sigma_alpha in {0.5, 1, 2}. The gamma = 0 ablation (BR0) uses the same s and sigma_alpha as BR. (v) Optimisation: 2,500 Adam steps with cosine learning-rate decay followed by up to 300 L-BFGS iterations (kept only if the objective improves). Training years are 1988-2013 (1986-1987 are needed as lags).

A1.3 Competitors. P1 gravity is estimated as a volume-weighted multinomial likelihood, which is the Poisson pseudo-likelihood with importer-year fixed effects concentrated out; pair effects carry a ridge penalty of 0.01. P2 TERGM uses the statistics listed in plan v1 with an L2 penalty of 0.001. P3 GNN receives the same exogenous information as BR (supplier anomalies at t-1 to t-3, restriction indicators at t-1 to t-3, the diagonal of Sigma_t, lagged unit values and export volumes) plus network features; hidden width and weight decay were selected on development validation from {32, 64} x {1e-4, 1e-3}; the final number of training epochs is the median best epoch of the five development seeds plus one; forecasts average five seeds.

A1.4 Selected configuration (config_final.json, SHA-256 eb654c028c1b9eeceffee628a4d7abd22f27f01845ffb5e0ff209336ec1fde6d):
{"br_sig_alpha": {"maize": 1.0, "rice": 1.0, "soybeans": 2.0, "wheat": 1.0}, "br_tau_scale": {"maize": 0.5, "rice": 0.25, "soybeans": 1.0, "wheat": 0.25}, "br_steps": 2500, "br_lbfgs": 300, "grav_ridge": 0.01, "gnn_h": {"maize": 64, "rice": 64, "soybeans": 64, "wheat": 64}, "gnn_wd": {"maize": 0.001, "rice": 0.001, "soybeans": 0.001, "wheat": 0.0001}, "gnn_epochs": {"maize": 39, "rice": 69, "soybeans": 27, "wheat": 43}, "gnn_seeds": 5, "synth_reps": 20, "pstar": "GNN"}

A1.5 Development validation losses (mean KL, 2006-2013, models trained on 1988-2005):
model         BR     BR0     GNN    GRAV  PERSIST   TERGM
c                                                        
maize     0.4356  0.4488  0.4048  0.7549   0.5986  0.5216
rice      0.3993  0.3945  0.3651  0.5105   0.5723  0.4389
soybeans  0.4259  0.4459  0.4057  0.5947   0.7747  0.4825
wheat     0.4748  0.4766  0.4432  0.6321   0.7632  0.5525
Strongest phenomenological competitor P* = GNN (lowest pooled development loss among P0-P3). Note that its development loss is optimistic because early stopping used the same validation years.

## A2. Frozen parameters

All models were re-estimated on 1988-2013 with the configuration above before unsealing. SHA-256 of every frozen parameter file:
{
 "BR0_maize.pt": "1dfb5168081290f4910b4c0a19d3b29dd2229d31eb95b7b72c58f34f1aef391b",
 "BR0_rice.pt": "52c487bac8dc23f89b0ef0246f1e8ed7facb4dee5ba129089c4b062d7c048b71",
 "BR0_soybeans.pt": "c9ab79363a75a52b855c6a233be7986562524cc734ff86a00dd9eb8793c3a54c",
 "BR0_wheat.pt": "f6b1fb8e004f95ac28b53dbca407e99d8af107d2c03b4f88063404ab4d188be4",
 "BR_maize.pt": "48524be242ada67db1fcd4a8f293769ce59f0faf85bc257f9f6ea96c0958413a",
 "BR_rice.pt": "1609101c6200ec73768576db29099649b8d51b9c325e636a3bdadd785cc2f8bd",
 "BR_soybeans.pt": "ce72c0d97c054f3f933295b108972e50a4d60430a4d17cbd08335e69496619a2",
 "BR_wheat.pt": "eda35b03e85e6a7c19542ed6fc177a970428c274c97bed87cb6e44ef8bc42bde",
 "GNN_maize_seed0.pt": "edca70d079f17d1712c5b20df92e6fdb081600875e4c78191f6ed232f155a38f",
 "GNN_maize_seed1.pt": "7e66001a06735511aaf3a22611db0ded4eb7521ab782cb73a02cad11d8e9dfbc",
 "GNN_maize_seed2.pt": "6f1f40c2786a4e1838eb1ea30dfc99ee165bd315edbfd67ef9c8f05bf4c6ea38",
 "GNN_maize_seed3.pt": "d1296e3180f6f5cf6ff3a74bbf0c3228d7571ced84664d66f169915d8b7cff2f",
 "GNN_maize_seed4.pt": "dad20a4e493646876ff53efe61359cbb61ab8f2dda01ef5a32add8cf83b7f726",
 "GNN_rice_seed0.pt": "e15317ac174460e61e1ea28f085eac892314900876147fd333cb350e275d3f61",
 "GNN_rice_seed1.pt": "18024569a512c0a531345dc20f951983ed744eb13fc903c839b9452b80a41c62",
 "GNN_rice_seed2.pt": "81fb755c1965d4566c85ab4a839234e35960a3bb03747b80f370c55f7779b46b",
 "GNN_rice_seed3.pt": "f1c738e426f7042b26c9de396e1e950a80660a3011489ce778f24b981c9fd498",
 "GNN_rice_seed4.pt": "0ad51cb42c5fd6257930f9fb5d12594b65bef96474f10df90bbff279c11a77f0",
 "GNN_soybeans_seed0.pt": "b7a52e29b4bd1c01c5edf3612971e600a577f4f7a86c278bcfb6329243c72afd",
 "GNN_soybeans_seed1.pt": "ac1cc9b6cec121bf999a027518f2703535605f79011c71a05927cd381eb7159a",
 "GNN_soybeans_seed2.pt": "048919dbce9cd27f6eb21774a8343e5bfdc3dfd30fd0957db1bbe067fcd93263",
 "GNN_soybeans_seed3.pt": "981c4fda1f6660b60f44be072949b0d92ccd39ee978233aa6876f403af32c0b0",
 "GNN_soybeans_seed4.pt": "58253f84e3c75235cc6b60a2ebf4f175a63fec264cbd7a9e664f56ce4aba2288",
 "GNN_wheat_seed0.pt": "d6b1c076bd71659009adc4afcecd353de6f2b19a08810e90af6f69c86ab6cb4e",
 "GNN_wheat_seed1.pt": "9cd170a26565f2b10f0ccdd14d0e5477eea0c619f5f129270106f287270cb579",
 "GNN_wheat_seed2.pt": "919fcdaf579e6f24a9dc7e7dbe8b5cb1637941374d098cfc77dddfd798d82c2a",
 "GNN_wheat_seed3.pt": "2524d4353118103aaa7ba00d7b9e3499b7ee09a2a018110a1929d7ed17bf7bdd",
 "GNN_wheat_seed4.pt": "d89c5f49c8b67e91eff14db9ee6e2ad7fef53f3f0d87c6637fd8c5e6f0bf7036",
 "GRAV_maize.pt": "0979e7c702f665345617a4cce7fb6d173824dbb4805f87dc38451ab325316708",
 "GRAV_rice.pt": "0ed19323e309e9e00cf5a9f961840fb14ad99066711bb29c31bdcd5b44d2f779",
 "GRAV_soybeans.pt": "bbca23eacdfd48aa72f50c39f1a921c3cd8396d3257f1abe1a3f7abb4038cac5",
 "GRAV_wheat.pt": "bba19c92d390dce686156cd7ff438d4dc7595aa6c2442ada266361fa38c8ffe2",
 "TERGM_maize_beta.npy": "5ee318e92341dc0ad42f12059b3143d14c9cec64554f8b2a7cb3d9f9ff930c1e",
 "TERGM_rice_beta.npy": "d6fb2d3367d2e73d8ba19129a5d81d311cbad4062867593fd1c018221a95c7e3",
 "TERGM_soybeans_beta.npy": "506950a48b94a55d1a394e4d33ebc1c5445ca5b94e8c23e4050b9e7b3da01bd0",
 "TERGM_wheat_beta.npy": "9a02aa709ab8bd8b558d1f3eaa0029f84074665c96ed2f7c67ae610cf159733f"
}

## A3. Evaluation details

Cases are importer-commodity-years with positive imports in t and t-1. 2024 is reported as an exploratory window. The decision rules of plan v1 section 6 are implemented verbatim in evaluate.py. Because P* = GNN, the plan's failure condition (BR not beating GNN in shock windows) coincides with criterion (a).

## A4. H2 implementation

Twenty synthetic panels per commodity were simulated from the frozen 1988-2013 BR fit with Dirichlet noise whose concentration matches the in-sample residual dispersion, and re-estimated with identical settings. Coverage is computed from Laplace posterior SDs of the importer parameters.

## A5. Disclosures

(1) When inspecting the structure of the FAOSTAT bulk file, the first five rows of the raw CSV were displayed; they concerned unrelated products (oilseed cake and cigarettes for Afghanistan and Albania) and included the years 2004, 2017 and 2019. No post-2013 data for the four study commodities were displayed. (2) The analysis plan is time-stamped and hash-sealed in the project's artifact store; it was not deposited on a public registry before unsealing.
