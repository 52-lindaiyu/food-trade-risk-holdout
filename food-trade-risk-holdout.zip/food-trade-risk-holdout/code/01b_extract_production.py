"""Extract area, yield and production of wheat (15), maize (56), paddy rice (27) and soybeans (236) from the FAOSTAT
Production (QCL) bulk file. python code/01b_extract_production.py [path to fao_qcl.zip] -> data/production_qcl.csv.gz
"""
import os, sys, zipfile, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
zp = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "raw", "fao_qcl.zip")
z = zipfile.ZipFile(zp); name = [n for n in z.namelist() if n.endswith("All_Data_(Normalized).csv")][0]
d = pd.read_csv(z.open(name), encoding="latin1", dtype={"Area Code (M49)": str})
d = d[d["Item Code"].isin([15, 56, 27, 236]) & d["Element"].isin(["Area harvested", "Yield", "Production"])]
d = d.rename(columns={"Area Code (M49)": "m49", "Area": "area", "Item Code": "item", "Element": "element", "Year": "year", "Value": "value"})
d["m49"] = d.m49.str.strip("'")
d = d[["m49", "area", "item", "element", "year", "value"]]
d.to_csv(os.path.join(ROOT, "data", "production_qcl.csv.gz") if len(sys.argv) < 3 else sys.argv[2], index=False)
print(d.shape)
