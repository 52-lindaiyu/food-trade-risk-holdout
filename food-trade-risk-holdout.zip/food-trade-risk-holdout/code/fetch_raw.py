"""Retrieve raw inputs into raw/ and data/raw2/ and verify checksums against data/MANIFEST_inputs.json.
python code/fetch_raw.py
FAOSTAT bulk files are re-issued periodically; the analysis used the December 2025 release (checksums below). If a later
release is downloaded the checksum test fails, and results may differ. The trade extracts in data/ are the authoritative inputs."""
import os, json, hashlib, requests
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
SRC = {"raw/fao_tm.zip": "https://bulks-faostat.fao.org/production/Trade_DetailedTradeMatrix_E_All_Data_(Normalized).zip",
       "raw/fao_qcl.zip": "https://bulks-faostat.fao.org/production/Production_Crops_Livestock_E_All_Data_(Normalized).zip",
       "data/raw2/dist_cepii.zip": "https://www.cepii.fr/distance/dist_cepii.zip",
       "data/raw2/wb_countries.json": "https://api.worldbank.org/v2/country?format=json&per_page=400",
       "data/raw2/country-codes.csv": "https://raw.githubusercontent.com/datasets/country-codes/master/data/country-codes.csv",
       "data/raw2/knmi_nino34.dat": "https://climexp.knmi.nl/data/iersst_nino3.4a.dat",
       "data/raw2/knmi_dmi3.dat": "https://climexp.knmi.nl/data/ihadisst1_dmi.dat",
       "data/raw2/cru_nao.dat": "https://crudata.uea.ac.uk/cru/data/nao/nao.dat",
       "data/raw2/gdhy.zip": "https://doi.pangaea.de/10.1594/PANGAEA.909132 (gdhy_v1.2_v1.3_20190128.zip)"}
man = json.load(open("data/MANIFEST_inputs.json"))["raw"]
for dst, url in SRC.items():
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if not os.path.exists(dst) and url.startswith("http") and " " not in url:
        r = requests.get(url, timeout=600); r.raise_for_status(); open(dst, "wb").write(r.content)
    if os.path.exists(dst):
        h = hashlib.sha256(open(dst, "rb").read()).hexdigest(); exp = man.get(os.path.basename(dst), {}).get("sha256")
        print(dst, "OK" if h == exp else f"checksum differs (expected {exp})")
    else: print(dst, "download manually from", url)
