"""Expand the audited policy-episode table to annual supplier-year indicators.

Variants (written to data/derived/policy_annual_<variant>.csv):
  base    1 if the episode is in force in any month of the year (the coding used in the sealed v1 analysis)
  sevdur  severity weight x fraction of months in force (max over overlapping episodes)
  legal   base coding excluding the 2022 Ukraine port blockade (a conflict shock, not a trade-policy choice)
Usage: python code/00_expand_policy.py
"""
import os, pandas as pd, numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
E = pd.read_csv(os.path.join(ROOT, "data", "policy_episodes_audited.csv"))
os.makedirs(os.path.join(ROOT, "data", "derived"), exist_ok=True)


def months_in_year(start, end, y):
    s = pd.Period(start, "M"); e = pd.Period(end, "M")
    a = max(s, pd.Period(f"{y}-01", "M")); b = min(e, pd.Period(f"{y}-12", "M"))
    return max(0, (b - a).n + 1) if b >= a else 0


def expand(variant):
    rows = {}
    for r in E.itertuples():
        if variant == "legal" and r.instrument == "conflict_blockade":
            continue
        for y in range(int(r.start[:4]), int(r.end[:4]) + 1):
            m = months_in_year(r.start, r.end, y)
            val = 1.0 if variant in ("base", "legal") else r.severity * m / 12.0
            key = (r.iso3, r.commodity, y)
            rows[key] = max(rows.get(key, 0.0), val)
    out = pd.DataFrame([(k[0], k[1], k[2], v) for k, v in rows.items()], columns=["iso3", "commodity", "year", "value"])
    return out.sort_values(["commodity", "iso3", "year"]).reset_index(drop=True)


if __name__ == "__main__":
    for v in ["base", "sevdur", "legal"]:
        d = expand(v); d.to_csv(os.path.join(ROOT, "data", "derived", f"policy_annual_{v}.csv"), index=False)
        print(v, len(d), round(d.value.sum(), 3))
