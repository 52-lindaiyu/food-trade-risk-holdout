"""Extract staple-cereal and soybean flows from the FAOSTAT Detailed Trade Matrix.

Pre-registration seal: rows with Year <= 2013 are written to the working file
(trade_pre2014.csv.gz). Rows with Year >= 2014 are written to a sealed file
(sealed/trade_post2013.csv.gz) whose SHA-256 digest is recorded; the sealed file
is not opened by any analysis script until the analysis plan has been frozen.
Only the set of years present and the byte size of the sealed file are logged.
"""
import zipfile, hashlib, json, os, sys
import pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)

ITEMS = {15: "wheat", 56: "maize", 236: "soybeans",
         27: "rice_paddy", 29: "rice_husked", 30: "rice_paddy_mill_eq", 31: "rice_milled", 32: "rice_broken"}
ELEMENTS = {5610: "imp_q", 5622: "imp_v", 5910: "exp_q", 5922: "exp_v"}
USECOLS = ["Reporter Country Code (M49)", "Partner Country Code (M49)", "Item Code",
           "Element Code", "Year", "Value"]

OUT = sys.argv[2] if len(sys.argv) > 2 else "data"
os.makedirs(OUT, exist_ok=True)
zt = zipfile.ZipFile(sys.argv[1] if len(sys.argv) > 1 else "raw/fao_tm.zip")
name = [n for n in zt.namelist() if n.endswith("(Normalized).csv")][0]
pre, post = [], []
with zt.open(name) as f:
    for ch in pd.read_csv(f, usecols=USECOLS, chunksize=5_000_000, encoding="latin1",
                          dtype={"Reporter Country Code (M49)": str, "Partner Country Code (M49)": str}):
        ch = ch[ch["Item Code"].isin(ITEMS) & ch["Element Code"].isin(ELEMENTS)]
        ch = ch[USECOLS]
        ch.columns = ["rep_m49", "par_m49", "item", "element", "year", "value"]
        ch["rep_m49"] = ch.rep_m49.str.strip("'"); ch["par_m49"] = ch.par_m49.str.strip("'")
        pre.append(ch[ch.year <= 2013]); post.append(ch[ch.year >= 2014])
pre = pd.concat(pre); post = pd.concat(post)
pre.to_csv(f"{OUT}/trade_pre2014.csv.gz", index=False)
post.to_csv(f"{OUT}/trade_post2013.csv.gz", index=False)
sha = hashlib.sha256(open(f"{OUT}/trade_post2013.csv.gz", "rb").read()).hexdigest()
# note: gzip headers carry a time stamp, so re-extraction reproduces the decompressed content, not the file digest
log = {"pre_rows": int(len(pre)), "pre_years": sorted(map(int, pre.year.unique())),
       "sealed_file": f"{OUT}/trade_post2013.csv.gz", "sealed_sha256": sha,
       "sealed_bytes": os.path.getsize(f"{OUT}/trade_post2013.csv.gz"),
       "sealed_years_present": sorted(map(int, post.year.unique()))}
json.dump(log, open(f"{OUT}/seal_log.json", "w"), indent=1)
print(json.dumps({k: v for k, v in log.items() if k != "pre_years"}))
