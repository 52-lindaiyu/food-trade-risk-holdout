"""Behavioural revealed-risk-governance model (BR) and phenomenological competitors (P0-P3).

All models produce one-step-ahead share forecasts s^_{n,t,.} from information dated <= t-1.
Compatible with torch 2.0 / numpy 1.26.
"""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as Fnn

torch.set_default_dtype(torch.float64)
FLOOR = 1e-4
EPS_LAG = 0.005


# ----------------------------------------------------------------------------- data
class Panel:
    def __init__(self, path):
        z = np.load(path, allow_pickle=False)
        self.I = list(z["I"]); self.S = list(z["S"]); self.years = list(z["years"]); self.ally = list(z["ally"])
        self.Q = z["Q"]; self.UV = z["UV"]; self.TOT = z["TOT"]; self.A = z["A"]; self.Z = z["Z"]; self.POL = z["POL"]
        self.SIG = z["SIG"]; self.D = z["D"]; self.CT = z["CT"]; self.CL = z["CL"]
        self.reg = list(z["reg"]); self.inc = list(z["inc"])
        N, T, K = self.Q.shape; self.N, self.T, self.K = N, T, K
        tot = np.nansum(self.Q, 2)
        self.valid = np.isfinite(self.Q[:, :, 0]) & (tot > 0)
        self.s = np.where(self.valid[:, :, None], self.Q / np.where(tot > 0, tot, 1)[:, :, None], np.nan)
        self.vol = np.where(self.valid, tot, 0.0)
        self.avail = np.ones((N, K))
        for a, i in enumerate(self.I):
            if i in self.S[:-1]: self.avail[a, self.S.index(i)] = 0.0
        # relative distance (1e4 km above nearest supplier)
        self.drel = (self.D - self.D.min(1, keepdims=True)) / 1e4
        self.logd = np.log(self.D)
        # groups
        g = [f"{r}|{c}" for r, c in zip(self.reg, self.inc)]
        self.groups = sorted(set(g)); self.gid = np.array([self.groups.index(x) for x in g])
        regs = sorted(set(self.reg)); self.rid = np.array([regs.index(x) for x in self.reg])
        # unit values: fill gaps with supplier median, then commodity-year median
        uv = np.where(self.UV > 0, self.UV, np.nan)
        pre = np.array(self.years) <= 2013  # fill values use training-period information only
        for k in range(K):
            m = np.nanmedian(uv[k][pre]) if np.isfinite(uv[k][pre]).any() else np.nan
            uv[k] = np.where(np.isfinite(uv[k]), uv[k], m)
        uv = np.where(np.isfinite(uv), uv, np.nanmedian(uv[:, pre]))
        self.luv = np.log(uv)  # K x T
        tt = np.where(np.isfinite(self.TOT), self.TOT, 0.0)
        self.ltot = np.log1p(tt)
        # sigma scale
        diag = np.array([np.diag(self.SIG[b]) for b in range(T)])
        self.sig_scale = float(np.median(diag))
        self.SIGn = self.SIG / self.sig_scale
        # shocks for memory (indexed on ally)
        zz = np.nan_to_num(self.Z, nan=0.0)
        self.shock = np.clip(-zz, 0.0, 3.0) ** 2  # K x len(ally); shortfalls capped at 3 SD
        self.yi = {y: b for b, y in enumerate(self.years)}
        self.ai = {y: b for b, y in enumerate(self.ally)}

    def lag_shares(self, t, lag=1):
        """shares at t-lag, zeros where missing (with availability mask)"""
        b = self.yi[t - lag]
        s = np.nan_to_num(self.s[:, b], nan=0.0)
        return s

    def peer_shares(self, t):
        """volume-weighted shares at t-1 of other importers in the same region"""
        b = self.yi[t - 1]; s = np.nan_to_num(self.s[:, b], nan=0.0); v = self.vol[:, b]
        out = np.zeros_like(s)
        for n in range(self.N):
            m = (self.rid == self.rid[n]); m[n] = False
            w = v * m
            if w.sum() <= 0: w = v.copy(); w[n] = 0
            out[n] = (w[:, None] * s).sum(0) / max(w.sum(), 1e-12)
        out = out * self.avail; out = out / np.maximum(out.sum(1, keepdims=True), 1e-12)
        return out

    def cases(self, years):
        """list of (n, t) with valid target at t and valid lag at t-1"""
        out = []
        for t in years:
            if t - 2 < self.years[0]: continue
            b = self.yi[t]; b1 = self.yi[t - 1]
            for n in range(self.N):
                if self.valid[n, b] and self.valid[n, b1]: out.append((n, t))
        return out


def kl_loss(s, shat):
    shat = np.maximum(shat, FLOOR); shat = shat / shat.sum(-1, keepdims=True)
    m = s > 0
    return np.where(m, s * np.log(np.where(m, s, 1) / shat), 0.0).sum(-1)


def hellinger(s, shat):
    shat = np.maximum(shat, FLOOR); shat = shat / shat.sum(-1, keepdims=True)
    return np.sqrt(0.5 * ((np.sqrt(s) - np.sqrt(shat)) ** 2).sum(-1))


# ----------------------------------------------------------------------------- tensors per year
def year_batch(P, t):
    """exogenous + lagged information for forecasting year t, all importers"""
    b = P.yi[t]; a1 = P.ai[t - 1]
    d = dict(
        slag=P.lag_shares(t, 1), slag2=P.lag_shares(t, 2) if t - 2 >= P.years[0] else P.lag_shares(t, 1),
        peer=P.peer_shares(t), luv=P.luv[:, P.yi[t - 1]] - P.luv[:, P.yi[t - 1]].mean(),
        ltot=P.ltot[:, P.yi[t - 1]], SIG=P.SIGn[b], shock=P.shock[:, :a1 + 1], pol=P.POL[:, :a1 + 1],
        z1=np.nan_to_num(P.Z[:, a1]), z2=np.nan_to_num(P.Z[:, a1 - 1]), z3=np.nan_to_num(P.Z[:, a1 - 2]),
        p1=P.POL[:, a1], p2=P.POL[:, a1 - 1], p3=P.POL[:, a1 - 2], t=t)
    return d


LMAX = 50


def stack_years(P, years):
    """Stack forecasting information for a list of target years (vectorised BR / gravity fitting)."""
    years = [t for t in years if t - 2 >= P.years[0]]
    ds = [year_batch(P, t) for t in years]
    H = np.zeros((len(years), LMAX, P.K)); HP = np.zeros((len(years), LMAX, P.K))
    for y, d in enumerate(ds):
        L = min(LMAX, d["shock"].shape[1])
        H[y, :L] = d["shock"][:, ::-1][:, :L].T; HP[y, :L] = d["pol"][:, ::-1][:, :L].T
    st = dict(years=years,
              slag=np.stack([d["slag"] for d in ds]), peer=np.stack([d["peer"] for d in ds]),
              luv=np.stack([d["luv"] for d in ds]), ltot=np.stack([d["ltot"] for d in ds]),
              z1=np.stack([d["z1"] for d in ds]), p1=np.stack([d["p1"] for d in ds]),
              SIG=np.stack([d["SIG"] for d in ds]), H=H, HP=HP,
              X1=np.stack([np.nan_to_num(P.Q[:, P.yi[t - 1]], nan=0.0) for t in years]),
              tt=np.array([(t - 2000) / 10.0 for t in years]),
              tgt=np.stack([np.nan_to_num(P.s[:, P.yi[t]], nan=0.0) for t in years]),
              msk=np.stack([(P.valid[:, P.yi[t]] & P.valid[:, P.yi[t - 1]]).astype(float) for t in years]),
              vol=np.stack([P.vol[:, P.yi[t]] for t in years]))
    return {k: (torch.tensor(v) if isinstance(v, np.ndarray) else v) for k, v in st.items()}


class BRModel(nn.Module):
    """Behavioural model (vectorised over years). ablate_risk=True fixes gamma=0 (dynamic logit)."""
    def __init__(self, P, ablate_risk=False, sig_alpha=2.0, tau=(1.0, 2.0, 1.0, 1.0), n_iter=60, step=0.7):
        super().__init__()
        N, K = P.N, P.K; G = len(P.groups)
        self.P = P; self.ablate = ablate_risk; self.sig_alpha = sig_alpha
        self.tau = torch.tensor(tau); self.n_iter = n_iter; self.step = step
        self.alpha = nn.Parameter(torch.zeros(N, K))
        init = torch.tensor([0.0, 0.0, 0.0, -2.0])
        self.u = nn.Parameter(torch.zeros(N, 4) + init)  # log gamma, delta, logit phi, logit omega
        self.mu_g = nn.Parameter(torch.zeros(G, 4) + init)
        self.rho = nn.Parameter(torch.tensor(1.0)); self.theta = nn.Parameter(torch.tensor(0.0))
        self.leta = nn.Parameter(torch.tensor(0.0)); self.lkappa = nn.Parameter(torch.tensor(0.0))
        self.zeta = nn.Parameter(torch.tensor(0.0)); self.zeta_p = nn.Parameter(torch.tensor(0.0))  # physical-availability controls
        self.avail = torch.tensor(P.avail); self.drel = torch.tensor(P.drel); self.gid = torch.tensor(P.gid)

    def params(self):
        g = torch.exp(self.u[:, 0]); delta = self.u[:, 1]; phi = torch.sigmoid(self.u[:, 2]); om = torch.sigmoid(self.u[:, 3])
        if self.ablate: g = torch.zeros_like(g)
        return g, delta, phi, om

    def forward_stack(self, st, override=None):
        ov = override or {}
        g, delta, phi, om = self.params()
        g = ov.get("gamma", g); delta = ov.get("delta", delta); phi = ov.get("phi", phi); om = ov.get("omega", om)
        v = self.alpha[None] + self.rho * torch.log(st["slag"] + EPS_LAG) - self.theta * st["luv"][:, None, :] \
            + self.zeta * st["z1"][:, None, :] - self.zeta_p * st["p1"][:, None, :]
        v = v.masked_fill((self.avail == 0)[None], -1e9)
        SIG = ov.get("sig", st["SIG"])
        eta = ov.get("eta", torch.exp(self.leta))
        kap = torch.nn.functional.softplus(self.lkappa) * ov.get("polscale", 1.0)
        lag = torch.arange(LMAX, dtype=torch.float64)
        Wm = (1 - phi)[:, None] * phi[:, None] ** lag[None, :]  # N x L
        Hx = st["H"] + kap * st["HP"]  # Y x L x K
        M = torch.einsum("nl,ylk->ynk", Wm, Hx)
        Dm = torch.exp(-delta[:, None] * self.drel)  # N x K
        # adaptive mirror-descent step: contraction requires step * gamma * ||Sigma~|| <= 1 (Gershgorin bound)
        rowsum = torch.einsum("ykl,nl->ynk", SIG.abs(), Dm).mul(Dm[None]).amax(2) + (eta * M * Dm[None] ** 2).amax(2)  # Y x N
        step = (1.0 / (1.0 + g[None, :] * rowsum)).clamp(max=self.step)[:, :, None]
        w = torch.softmax(v, 2)
        for _ in range(self.n_iter):
            Sw = torch.einsum("ykl,ynl->ynk", SIG, Dm[None] * w) * Dm[None] + eta * M * (Dm ** 2)[None] * w
            wn = torch.softmax(v - g[None, :, None] * Sw, 2)
            wprev = w
            w = torch.exp((1 - step) * torch.log(w.clamp_min(1e-300)) + step * torch.log(wn.clamp_min(1e-300)))
            w = w / w.sum(2, keepdim=True)
        self.last_resid = float((w - wprev).abs().sum(2).max())
        shat = (1 - om)[None, :, None] * w + om[None, :, None] * st["peer"]
        return shat, w

    def penalty(self):
        pen = 0.5 * (self.alpha ** 2).sum() / self.sig_alpha ** 2
        dev = (self.u - self.mu_g[self.gid]) / self.tau
        pen = pen + 0.5 * (dev ** 2).sum()
        pen = pen + 0.5 * ((self.mu_g - self.mu_g.mean(0, keepdim=True)) ** 2).sum()
        pen = pen + 0.5 * (self.leta ** 2 + self.lkappa ** 2) / 4.0
        return pen


class GravityPPML(nn.Module):
    """Dynamic structural gravity: Poisson PML with importer-year effects (concentrated out, which makes the
    likelihood a volume-weighted multinomial over suppliers), pair effects, lagged log flow, the supplier's
    lagged log total exports and supplier-specific linear trends."""
    def __init__(self, P, ridge=1e-2):
        super().__init__()
        self.P = P; self.ridge = ridge
        self.alpha = nn.Parameter(torch.zeros(P.N, P.K)); self.b1 = nn.Parameter(torch.tensor(0.5))
        self.b2 = nn.Parameter(torch.tensor(0.5)); self.trend = nn.Parameter(torch.zeros(P.K))
        self.avail = torch.tensor(P.avail)

    def forward_stack(self, st, override=None):
        v = self.alpha[None] + self.b1 * torch.log1p(st["X1"] / 1000.0) + self.b2 * st["ltot"][:, None, :] \
            + self.trend[None, None, :] * st["tt"][:, None, None]
        v = v.masked_fill((self.avail == 0)[None], -1e9)
        return torch.softmax(v, 2), None

    def penalty(self):
        return 0.5 * self.ridge * (self.alpha ** 2).sum()


def fit_stack(model, st, weights="equal", steps=1500, lr=0.05, lbfgs_iter=200, tol=0.0, verbose=False):
    """Adam warm-up followed by L-BFGS polish of the penalised negative log-likelihood."""
    if weights == "equal": W = st["msk"]
    else:
        W = st["msk"] * st["vol"]; W = W / (W.sum() / st["msk"].sum())
    def objective():
        shat, _ = model.forward_stack(st)
        nll = -(W * (st["tgt"] * torch.log(shat.clamp_min(1e-12))).sum(2)).sum()
        return nll + model.penalty(), nll
    opt = torch.optim.Adam(model.parameters(), lr=lr); prev = np.inf; hist = []
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=steps, eta_min=lr * 0.02)
    for it in range(steps):
        opt.zero_grad(); loss, nll = objective(); loss.backward(); opt.step(); sched.step()
        hist.append(float(loss))
        if tol > 0 and it > 300 and abs(prev - float(loss)) < tol * abs(float(loss)): break
        prev = float(loss)
    if lbfgs_iter:
        state = {k: v.clone() for k, v in model.state_dict().items()}
        with torch.no_grad(): before = float(objective()[0])
        opt2 = torch.optim.LBFGS(model.parameters(), lr=0.5, max_iter=lbfgs_iter, line_search_fn="strong_wolfe",
                                 tolerance_grad=1e-7, tolerance_change=1e-10, history_size=20)
        def cl():
            opt2.zero_grad(); l, _ = objective(); l.backward(); return l
        try:
            opt2.step(cl)
        except Exception:
            pass
        with torch.no_grad(): after = float(objective()[0])
        if not np.isfinite(after) or after > before: model.load_state_dict(state)
    with torch.no_grad():
        loss, nll = objective()
    return dict(loss=float(loss), nll=float(nll), adam_steps=len(hist), hist=hist[::25])


def predict_stack(model, P, years, override=None):
    st = stack_years(P, years)
    with torch.no_grad():
        shat, w = model.forward_stack(st, override)
    return {t: shat[y].numpy() for y, t in enumerate(st["years"])}


def fit_torch(model, P, years, weights="equal", max_iter=300, lr=1.0, verbose=False):
    """MAP / PML fit with L-BFGS over all (n,t) cases in `years`."""
    batches = [(t, year_batch(P, t)) for t in years if t - 2 >= P.years[0]]
    tgt = {t: torch.tensor(np.nan_to_num(P.s[:, P.yi[t]], nan=0.0)) for t, _ in batches}
    msk = {t: torch.tensor((P.valid[:, P.yi[t]] & P.valid[:, P.yi[t - 1]]).astype(float)) for t, _ in batches}
    vw = {t: torch.tensor(P.vol[:, P.yi[t]]) for t, _ in batches}
    vnorm = np.mean([float((vw[t] * msk[t]).sum()) for t, _ in batches]) / max(np.mean([float(msk[t].sum()) for t, _ in batches]), 1)
    opt = torch.optim.LBFGS([p for p in model.parameters() if p.requires_grad], lr=lr, max_iter=max_iter,
                            line_search_fn="strong_wolfe", tolerance_grad=1e-6, tolerance_change=1e-9, history_size=20)
    def closure():
        opt.zero_grad()
        nll = 0.0
        for t, d in batches:
            shat, _ = model.forward_year(d)
            ll = (tgt[t] * torch.log(shat.clamp_min(1e-12))).sum(1)
            w = msk[t] if weights == "equal" else msk[t] * vw[t] / vnorm
            nll = nll - (w * ll).sum()
        loss = nll + model.penalty()
        loss.backward()
        return loss
    loss = opt.step(closure)
    return float(loss)


def predict_torch(model, P, years, **kw):
    out = {}
    with torch.no_grad():
        for t in years:
            shat, w = model.forward_year(year_batch(P, t), **kw) if kw else model.forward_year(year_batch(P, t))
            out[t] = shat.numpy()
    return out


# ----------------------------------------------------------------------------- P0 persistence
def predict_persistence(P, years):
    out = {}
    for t in years:
        s = P.lag_shares(t, 1) * P.avail
        s = np.maximum(s, FLOOR) * P.avail; out[t] = s / s.sum(1, keepdims=True)
    return out


# ----------------------------------------------------------------------------- P2 TERGM (MPLE)
def tergm_features(P, t, thr=0.01):
    s1 = P.lag_shares(t, 1); s2 = P.lag_shares(t, 2) if t - 2 >= P.years[0] else s1
    y1 = (s1 >= thr).astype(float); y2 = (s2 >= thr).astype(float)
    pop = np.log1p(y1.sum(0))[None, :].repeat(P.N, 0)
    deg = np.log1p(y1.sum(1))[:, None].repeat(P.K, 1)
    co = (y1 @ y1.T > 0).astype(float); np.fill_diagonal(co, 0)  # co-buyers sharing >= 1 supplier
    ncob = co.sum(1, keepdims=True)
    closure = (co @ y1) / np.maximum(ncob, 1)  # share of co-buyers who buy from k
    X = np.stack([np.ones_like(y1), y1, y2, y1 * y2, pop, deg, closure, P.logd - 8.5, P.CT, P.CL], -1)
    return X, y1, s1


def fit_tergm(P, years, thr=0.01, l2=1e-3):
    Xs, ys = [], []
    for t in years:
        if t - 2 < P.years[0]: continue
        b = P.yi[t]; b1 = P.yi[t - 1]
        m = P.valid[:, b] & P.valid[:, b1]
        X, _, _ = tergm_features(P, t, thr)
        y = (np.nan_to_num(P.s[:, b]) >= thr).astype(float)
        mm = m[:, None] & (P.avail > 0)
        Xs.append(X[mm]); ys.append(y[mm])
    X = torch.tensor(np.concatenate(Xs)); y = torch.tensor(np.concatenate(ys))
    beta = torch.zeros(X.shape[1], requires_grad=True)
    opt = torch.optim.LBFGS([beta], max_iter=500, line_search_fn="strong_wolfe")
    def cl():
        opt.zero_grad(); l = Fnn.binary_cross_entropy_with_logits(X @ beta, y, reduction="sum") + l2 * (beta ** 2).sum(); l.backward(); return l
    opt.step(cl)
    return beta.detach().numpy()


def predict_tergm(P, beta, years, thr=0.01):
    out, probs = {}, {}
    for t in years:
        X, y1, s1 = tergm_features(P, t, thr)
        p = 1 / (1 + np.exp(-(X @ beta)))
        # magnitude: lagged share if linked, else supplier's mean share among its current customers
        cust = (y1 > 0)
        mean_cust = np.where(cust.sum(0) > 0, (s1 * cust).sum(0) / np.maximum(cust.sum(0), 1), thr)
        mag = np.where(y1 > 0, s1, mean_cust[None, :])
        s = np.maximum(p * mag, FLOOR) * P.avail
        out[t] = s / s.sum(1, keepdims=True); probs[t] = p
    return out, probs


# ----------------------------------------------------------------------------- P3 GNN
class BipartiteGNN(nn.Module):
    """Two rounds of share-weighted message passing between importer and supplier nodes; edge MLP gives
    next-year share logits. Receives the same exogenous information as BR (lagged anomalies, restriction
    indicators, diagonal of the real-time covariance) plus network features."""
    def __init__(self, n_imp, n_sup, n_grp, h=32, drop=0.1):
        super().__init__()
        self.emb_i = nn.Embedding(n_imp, 8); self.emb_k = nn.Embedding(n_sup, 8); self.emb_g = nn.Embedding(n_grp, 4)
        self.fi = nn.Sequential(nn.Linear(8 + 4 + 2, h), nn.ReLU())
        self.fk = nn.Sequential(nn.Linear(8 + 9, h), nn.ReLU())
        self.mi = nn.ModuleList([nn.Sequential(nn.Linear(2 * h, h), nn.ReLU()) for _ in range(2)])
        self.mk = nn.ModuleList([nn.Sequential(nn.Linear(2 * h, h), nn.ReLU()) for _ in range(2)])
        self.edge = nn.Sequential(nn.Linear(2 * h + 7, h), nn.ReLU(), nn.Dropout(drop), nn.Linear(h, h), nn.ReLU(), nn.Linear(h, 1))

    def forward(self, xi, xk, e, wadj, avail, gid):
        N, K = wadj.shape
        hi = self.fi(torch.cat([self.emb_i.weight, self.emb_g(gid), xi], 1))
        hk = self.fk(torch.cat([self.emb_k.weight, xk], 1))
        for l in range(2):
            mi = wadj @ hk; mk = (wadj.T @ hi) / wadj.sum(0).clamp_min(1e-6)[:, None]
            hi, hk = self.mi[l](torch.cat([hi, mi], 1)), self.mk[l](torch.cat([hk, mk], 1))
        z = torch.cat([hi[:, None, :].expand(N, K, -1), hk[None, :, :].expand(N, K, -1), e], 2)
        logit = self.edge(z)[:, :, 0] + torch.log(avail.clamp_min(1e-12))
        return torch.log_softmax(logit, 1)


def gnn_inputs(P, t):
    d = year_batch(P, t)
    s1 = d["slag"]; s2 = d["slag2"]
    vol1 = np.log1p(P.vol[:, P.yi[t - 1]] / 1000.0)
    xi = np.stack([vol1 / 10, (s1 > 0.01).sum(1) / P.K], 1)
    diag = np.diag(d["SIG"])
    xk = np.stack([d["ltot"] / 15, d["luv"], d["z1"], d["z2"], d["z3"], d["p1"], d["p2"], d["p3"], diag], 1)
    e = np.stack([np.log(s1 + EPS_LAG), np.log(s2 + EPS_LAG), (P.logd - 8.5), P.CT, P.CL,
                  np.log(d["peer"] + EPS_LAG), (s1 > 0.01).astype(float)], -1)
    T = lambda x: torch.tensor(x, dtype=torch.float32)
    return T(xi), T(xk), T(e), T(s1 + 1e-3), T(P.avail)


def fit_gnn(P, train_years, val_years=None, h=32, wd=1e-4, epochs=400, lr=3e-3, seed=0, device="cpu", patience=40):
    torch.manual_seed(seed); np.random.seed(seed)
    net = BipartiteGNN(P.N, P.K, len(P.groups), h=h).to(device).float()
    opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=wd)
    gid = torch.tensor(P.gid, dtype=torch.long, device=device)
    def pack(years):
        out = []
        for t in years:
            if t - 2 < P.years[0]: continue
            b = P.yi[t]; m = P.valid[:, b] & P.valid[:, P.yi[t - 1]]
            if m.sum() == 0: continue
            xs = [x.to(device) for x in gnn_inputs(P, t)]
            out.append((xs, torch.tensor(np.nan_to_num(P.s[:, b]), dtype=torch.float32, device=device),
                        torch.tensor(m.astype(np.float32), device=device)))
        return out
    tr = pack(train_years); va = pack(val_years) if val_years else None
    best, best_state, best_ep, bad = np.inf, None, 0, 0
    hist = []
    for ep in range(epochs):
        net.train(); opt.zero_grad(); loss = 0.0
        for xs, s, m in tr:
            lp = net(*xs, gid); loss = loss - ((s * lp).sum(1) * m).sum() / m.sum()
        (loss / len(tr)).backward(); opt.step()
        if va is not None:
            net.eval()
            with torch.no_grad():
                vl = 0.0; cnt = 0.0
                for xs, s, m in va:
                    lp = net(*xs, gid); ent = torch.where(s > 0, s * torch.log(s.clamp_min(1e-12)), torch.zeros_like(s)).sum(1)
                    vl += float(((ent - (s * lp).sum(1)) * m).sum()); cnt += float(m.sum())
            vl /= cnt; hist.append(vl)
            if vl < best - 1e-5: best, best_ep, bad = vl, ep, 0; best_state = {k: v.clone() for k, v in net.state_dict().items()}
            else:
                bad += 1
                if bad > patience: break
    if best_state is not None: net.load_state_dict(best_state)
    return net, dict(best_val=best, best_epoch=best_ep, hist=hist)


def predict_gnn(nets, P, years, device="cpu"):
    gid = torch.tensor(P.gid, dtype=torch.long, device=device); out = {}
    with torch.no_grad():
        for t in years:
            xs = [x.to(device) for x in gnn_inputs(P, t)]
            ps = [torch.exp(net.eval()(*xs, gid)).double().cpu().numpy() for net in nets]
            out[t] = np.mean(ps, 0)
    return out
