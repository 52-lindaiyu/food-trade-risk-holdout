"""Build importer-supplier share panels from FAOSTAT bilateral trade (rules of analysis plan v1, section 1).

build_flows(tr) -> long bilateral quantity/value table in harmonised ISO3 codes.
Supplier and importer sets are defined from years <= 2013 only and are frozen in data/sets.json.
"""
import os, json, numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CODES = pd.read_csv(os.path.join(ROOT, "data", "raw2", "country-codes.csv"), keep_default_na=False, dtype=str)
M49_ISO = {r["M49"].zfill(3): r["ISO3166-1-Alpha-3"] for _, r in CODES.iterrows() if r["M49"] and r["ISO3166-1-Alpha-3"]}
# harmonised entities (predecessor -> successor used as a continuous unit)
M49_ISO.update({"810": "RUS", "058": "BEL", "200": "CZE", "890": "SRB", "891": "SRB", "230": "ETH", "736": "SDN",
                "156": "CHN", "158": "TWN"})
COMMOD = {15: "wheat", 56: "maize", 30: "rice", 236: "soybeans"}


def build_flows(tr):
    tr = tr[tr.item.isin(COMMOD)].copy()
    tr["c"] = tr.item.map(COMMOD)
    tr["rep"] = tr.rep_m49.str.zfill(3).map(M49_ISO); tr["par"] = tr.par_m49.str.zfill(3).map(M49_ISO)
    tr = tr.dropna(subset=["rep", "par"]); tr = tr[tr.rep != tr.par]
    el = {5610: "imp_q", 5622: "imp_v", 5910: "exp_q", 5922: "exp_v"}
    tr["el"] = tr.element.map(el)
    w = tr.pivot_table(index=["c", "rep", "par", "year"], columns="el", values="value", aggfunc="sum").reset_index()
    imp = w[["c", "rep", "par", "year", "imp_q", "imp_v"]].rename(columns={"rep": "i", "par": "j"})
    exp = w[["c", "rep", "par", "year", "exp_q", "exp_v"]].rename(columns={"rep": "j", "par": "i"})
    f = imp.merge(exp, on=["c", "i", "j", "year"], how="outer")
    f["q"] = f.imp_q.where(f.imp_q.notna() & (f.imp_q > 0), f.exp_q)
    f["v"] = f.imp_v.where(f.imp_v.notna() & (f.imp_v > 0), f.exp_v)
    # exporter-side value/quantity for unit values (FOB-side when available)
    f["qx"] = f.exp_q.where(f.exp_q.notna() & (f.exp_q > 0), f.imp_q)
    f["vx"] = f.exp_v.where(f.exp_v.notna() & (f.exp_v > 0), f.imp_v)
    f = f[(f.q > 0)][["c", "i", "j", "year", "q", "v", "qx", "vx"]]
    return f


def define_sets(f):
    sets = {}
    pre = f[f.year <= 2013]
    for c in COMMOD.values():
        g = pre[pre.c == c]
        ex = g.groupby(["year", "j"]).qx.sum().unstack(fill_value=0)
        shr = ex.div(ex.sum(1), axis=0)
        cand = shr.columns[(shr >= 0.01).any()]
        cum = ex[cand].sum().sort_values(ascending=False)
        S = list(cum.index[:15])
        imp = g.groupby(["year", "i"]).q.sum().unstack(fill_value=0).reindex(range(1986, 2014), fill_value=0)
        m = imp.loc[2004:2013].mean(); npos = (imp > 0).sum()
        I = sorted(imp.columns[(m >= 50_000) & (npos >= 15)])
        sets[c] = {"S": S, "I": I}
    return sets


def shares(f, sets, c):
    S = sets[c]["S"]; I = sets[c]["I"]; K = len(S) + 1
    g = f[(f.c == c) & f.i.isin(I)].copy()
    g["jj"] = np.where(g.j.isin(S), g.j, "ROW")
    tab = g.groupby(["i", "year", "jj"]).q.sum().unstack(fill_value=0)
    tab = tab.reindex(columns=S + ["ROW"], fill_value=0)
    return tab  # index (i, year), columns suppliers; quantities in tonnes


def unit_values(f, sets, c):
    S = sets[c]["S"]
    g = f[f.c == c].copy(); g["jj"] = np.where(g.j.isin(S), g.j, "ROW")
    a = g.groupby(["year", "jj"])[["vx", "qx"]].sum()
    uv = (a.vx * 1000 / a.qx).unstack()  # USD per tonne
    tot = a.qx.unstack()
    return uv.reindex(columns=S + ["ROW"]), tot.reindex(columns=S + ["ROW"])
