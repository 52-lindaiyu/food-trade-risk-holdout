"""Hash gate. python code/hashgate.py check   -> verifies sealed record and inputs (exit 1 on any mismatch)
           python code/hashgate.py freeze  -> writes out/fit_param_sha256.json for the fitted v2 parameters
           python code/hashgate.py verify-fits -> checks fitted parameters against that manifest before forecasting"""
import os, sys, json, glob, hashlib, gzip
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)


def sha(p, content=False):
    h = hashlib.sha256()
    f = gzip.open(p) if content else open(p, "rb")
    for ch in iter(lambda: f.read(1 << 20), b""): h.update(ch)
    return h.hexdigest()


def check():
    bad = []
    for doc in ["analysis_plan_v1", "amendment_A"]:
        exp = json.load(open(f"prereg/{doc}.sha256.json")); exp = exp.get("sha256", list(exp.values())[0]) if isinstance(exp, dict) else exp
        if sha(f"prereg/{doc}.md") != exp: bad.append(doc)
    if sha("data/trade_post2013.csv.gz") != "28c630fc4c57e710fe308b3e4e503bc082735c8fa28b09d8cd3fce6c6690a690":
        man = json.load(open("data/MANIFEST_inputs.json")).get("content_sha256", {})
        if man.get("trade_post2013.csv.gz") != sha("data/trade_post2013.csv.gz", True): bad.append("sealed trade file")
    fh = json.load(open("prereg/frozen_param_hashes.json"))
    for k, v in fh.items():
        p = f"data/v1_frozen/{k}"
        if os.path.exists(p) and sha(p) != v: bad.append(p)
    man = json.load(open("data/MANIFEST_inputs.json"))
    for k, v in man["arrays"].items():
        p = f"data/arrays/{k}"
        if os.path.exists(p) and sha(p) != v: bad.append(p)
    print("hash gate:", "OK" if not bad else f"MISMATCH {bad}"); return not bad


def freeze():
    d = {os.path.basename(p): sha(p) for p in sorted(glob.glob("out/fit/*.pt") + glob.glob("out/fit/*.npy"))}
    json.dump(d, open("out/fit_param_sha256.json", "w"), indent=0); print(len(d), "fitted parameter files hashed")


def verify_fits():
    d = json.load(open("out/fit_param_sha256.json")); have = [k for k in d if os.path.exists(f"out/fit/{k}")]
    bad = [k for k in have if sha(f"out/fit/{k}") != d[k]]
    print(f"fitted parameters: {len(have)} of {len(d)} present;", "OK" if not bad else f"MISMATCH {bad}"); return not bad


if __name__ == "__main__":
    ok = {"check": check, "freeze": lambda: freeze() or True, "verify-fits": verify_fits}[sys.argv[1]]()
    sys.exit(0 if ok else 1)
