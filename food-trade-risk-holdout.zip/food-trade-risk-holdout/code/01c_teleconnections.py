"""Annual teleconnection indices from the KNMI Climate Explorer (Nino3.4 ERSSTv5, DMI HadISST1) and CRU (station NAO).
python code/01c_teleconnections.py -> data/raw2/teleconnections_annual.csv
N34_DJF(y) = mean(Dec y-1, Jan y, Feb y); N34_JAS(y) = mean(Jul-Sep y); DMI_SON(y) = mean(Sep-Nov y);
DMI_SON_lag(y) = DMI_SON(y-1); NAO_DJFM(y) = mean(Dec y-1, Jan-Mar y). Missing values (-99.99 / -999.9) are NaN.
"""
import os, numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); R2 = os.path.join(ROOT, "data", "raw2")


def read_monthly(fn):
    rows = []
    for line in open(os.path.join(R2, fn)):
        if line.startswith("#") or not line.strip(): continue
        p = line.split()
        if len(p) == 2:  # fractional-year format (year + (month-1)/12, value)
            x = float(p[0]); y = int(np.floor(x + 1e-6)); m = int(round((x - y) * 12)) + 1
            rows.append((y, m, float(p[1]))); continue
        if len(p) < 13: continue
        try: y = int(p[0]); v = [float(x) for x in p[1:13]]
        except ValueError: continue
        rows += [(y, m + 1, v[m]) for m in range(12)]
    d = pd.DataFrame(rows, columns=["year", "month", "v"]).drop_duplicates(["year", "month"]).pivot(index="year", columns="month", values="v")
    return d.mask(d <= -99)


def seasonal(d, months, prev_dec=False):
    out = {}
    for y in d.index:
        vals = [d.loc[y, m] for m in months]
        if prev_dec: vals.append(d.loc[y - 1, 12] if (y - 1) in d.index else np.nan)
        out[y] = np.mean(vals) if np.all(np.isfinite(vals)) else np.nan
    return pd.Series(out)


if __name__ == "__main__":
    n34 = read_monthly("knmi_nino34.dat"); dmi = read_monthly("knmi_dmi3.dat"); nao = read_monthly("cru_nao.dat")
    t = pd.DataFrame({"N34_DJF": seasonal(n34, [1, 2], True), "N34_JAS": seasonal(n34, [7, 8, 9]), "DMI_SON": seasonal(dmi, [9, 10, 11])})
    t["DMI_SON_lag"] = t["DMI_SON"].shift(1); t["NAO_DJFM"] = seasonal(nao, [1, 2, 3], True)
    t = t.loc[1960:2025]; t.index.name = "year"; t.to_csv(os.path.join(R2, "teleconnections_annual.csv"))
    print(t.tail(3))
