"""Identification, synthetic recovery (H2) and portfolio-sensitivity summaries for the v2 fits.
python code/analyse_identification.py -> results/v2/{params_importer.csv, params_commodity.csv, identification.csv,
                                          h2_importer.csv, h2_group.csv, h2_reps.csv, perception_groups.csv, perception_delta.csv}
"""
import os, json, glob, numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
COMMODS = ["wheat", "maize", "rice", "soybeans"]; PN = ["log_gamma", "delta", "logit_phi", "logit_omega"]
TAU = np.array([1.0, 2.0, 1.0, 1.0]); cfg = json.load(open("config/config_v2.json")); out = "results/v2"; os.makedirs(out, exist_ok=True)
INC = {"Low income": "Low", "Lower middle income": "Lower-middle", "Upper middle income": "Upper-middle", "High income": "High"}
pi_rows, pc_rows, id_rows, h2i, h2g, h2r, pg, pdl = [], [], [], [], [], [], [], []
for c in COMMODS:
    z = np.load(f"data/arrays/arrays_{c}_pre.npz"); I = list(z["I"]); inc = list(z["inc"]); reg = list(z["reg"])
    fj = json.load(open(f"out/fit/BR_{c}_vmain.json")); p = fj["params"]; u = np.array(p["u"])
    tau = cfg["br_tau_scale"][c] * TAU; L = np.load(f"out/post/laplace_{c}.npz")
    sd_m, sd_d, sd_c, sd_k = L["unit_u_sd"], L["unit_dev_sd"], L["unit_u_sd_conditional"], L["cal_dev_sd"]
    for n, iso in enumerate(I):
        r = dict(c=c, iso=iso, income=inc[n], region=reg[n])
        for j, nm in enumerate(PN):
            r[nm] = u[n, j]; r[nm + "_sd_marg"] = sd_m[n, j]; r[nm + "_sd_dev"] = sd_d[n, j]; r[nm + "_sd_cond"] = sd_c[n, j]; r[nm + "_sd_dev_cal"] = sd_k[n, j]
        pi_rows.append(r)
    g = L["unit_glob_sd"]; gc = L["cal_glob_sd"]
    pc_rows.append(dict(c=c, rho=p["rho"], rho_sd=g[0], theta=p["theta"], theta_sd=g[1], eta=p["eta"], log_eta_sd=g[2], kappa=p["kappa"],
                        l_kappa_sd=g[3], zeta=p["zeta"], zeta_sd=g[4], zeta_p=p["zeta_p"], zeta_p_sd=g[5], dirichlet_conc=fj["dirichlet_conc"],
                        hessian_pd=bool(L["unit_pd"]), min_eig=float(L["unit_min_eig"]), n_neg_eig=int(L["unit_n_neg_eig"]),
                        hessian_pd_cal=bool(L["cal_pd"]), sig_scale=fj["prep"]["sig_scale"], uv_imputed_le2013=fj["prep"]["uv_imputed_cells_le_cutoff"],
                        uv_imputed_after2013=fj["prep"]["uv_imputed_cells_after_cutoff"], train_loss=fj["loss"], final_grad=fj["final_grad_maxabs"],
                        max_fp_resid_training=fj["max_fp_resid_training"]))
    for j, nm in enumerate(PN):
        rat_c = sd_c[:, j] / tau[j]; rat_d = sd_d[:, j] / tau[j]; rat_k = sd_k[:, j] / tau[j]
        lo, hi = u[:, j] - 1.96 * sd_m[:, j], u[:, j] + 1.96 * sd_m[:, j]
        id_rows.append(dict(c=c, param=nm, n=len(I), weak_cond=float((rat_c > 0.8).mean()), weak_dev=float((rat_d > 0.8).mean()),
                            weak_dev_cal=float((rat_k > 0.8).mean()), median_ratio_dev=float(np.median(rat_d)), median_marg_sd=float(np.median(sd_m[:, j])),
                            sig_pos=int((lo > 0).sum()), sig_neg=int((hi < 0).sum()), median=float(np.median(u[:, j])),
                            median_identified=float(np.median(u[rat_d <= 0.8, j])) if (rat_d <= 0.8).any() else np.nan, n_identified=int((rat_d <= 0.8).sum())))
    # synthetic recovery
    S = [np.load(f) for f in sorted(glob.glob(f"out/synth/synth_{c}_*.npz"))]
    UT = np.array([s["u_true"] for s in S]); UH = np.array([s["u_hat"] for s in S]); SD = np.array([s["u_sd"] for s in S]); SDC = np.array([s["u_sd_cond"] for s in S])
    MT = np.array([s["mu_true"] for s in S]); MH = np.array([s["mu_hat"] for s in S]); MSD = np.array([s["mu_sd"] for s in S])
    jit = np.array([float(s["jitter"]) for s in S]); gid = S[0]["gid"]; G = MT.shape[1]
    gsize = np.bincount(gid, minlength=G)
    for j, nm in enumerate(PN):
        e = UH[:, :, j] - UT[:, :, j]
        cov = lambda q, sd: float((np.abs(e) <= q * sd[:, :, j]).mean())
        for sub, m in [("all", np.ones(len(S), bool)), ("standard_init", jit == 0), ("jittered_init", jit > 0)]:
            ee = e[m]
            h2i.append(dict(c=c, param=nm, subset=sub, reps=int(m.sum()), corr=float(np.corrcoef(UT[m][:, :, j].ravel(), UH[m][:, :, j].ravel())[0, 1]),
                            bias_over_tau=float(ee.mean() / tau[j]), rmse_over_tau=float(np.sqrt((ee ** 2).mean()) / tau[j]),
                            cov80_marg=float((np.abs(ee) <= 1.2816 * SD[m][:, :, j]).mean()), cov95_marg=float((np.abs(ee) <= 1.96 * SD[m][:, :, j]).mean()),
                            cov80_cond=float((np.abs(ee) <= 1.2816 * SDC[m][:, :, j]).mean()), cov95_cond=float((np.abs(ee) <= 1.96 * SDC[m][:, :, j]).mean())))
        eg = MH[:, :, j] - MT[:, :, j]; occ = gsize > 0
        absbias = np.abs(eg.mean(0))[occ] / tau[j]
        c80 = (np.abs(eg) <= 1.2816 * MSD[:, :, j])[:, occ]; c95 = (np.abs(eg) <= 1.96 * MSD[:, :, j])[:, occ]
        rep80 = c80.mean(1); rep95 = c95.mean(1)
        reg_pass = bool(absbias.mean() < 0.25 and 0.70 <= c80.mean() <= 0.98 and 0.70 <= c95.mean() <= 0.98)
        cal_pass = bool(absbias.mean() < 0.25 and 0.70 <= c80.mean() <= 0.90 and 0.85 <= c95.mean() <= 0.99)
        h2g.append(dict(c=c, param=nm, groups=int(occ.sum()), mean_abs_group_bias_over_tau=float(absbias.mean()), max_abs_group_bias_over_tau=float(absbias.max()),
                        mean_abs_error_over_tau=float(np.abs(eg[:, occ]).mean() / tau[j]), group_cov80=float(c80.mean()), group_cov80_mcse=float(rep80.std(ddof=1) / np.sqrt(len(rep80))),
                        group_cov95=float(c95.mean()), group_cov95_mcse=float(rep95.std(ddof=1) / np.sqrt(len(rep95))), pass_registered_range=reg_pass, pass_level_specific=cal_pass))
        for k in range(len(S)):
            h2r.append(dict(c=c, param=nm, rep=k, jitter=jit[k], corr=float(np.corrcoef(UT[k, :, j], UH[k, :, j])[0, 1]),
                            mean_group_error_over_tau=float(eg[k, occ].mean() / tau[j]), group_cov95=float(c95[k].mean()), importer_cov95=float((np.abs(e[k]) <= 1.96 * SD[k, :, j]).mean())))
    # portfolio sensitivity (parameter perturbations), point estimates and Laplace-draw intervals
    Pz = np.load(f"out/post/perception_{c}.npz"); names = list(Pz["names"]); L1p, dvp, L1d, dvd = Pz["L1_point"], Pz["dv_point"], Pz["L1_draws"], Pz["dv_draws"]
    incs = np.array([INC.get(x, "NA") for x in inc]); rat_d = sd_d / tau
    for gname in ["Low", "Lower-middle", "Upper-middle", "High"]:
        m = incs == gname
        if m.sum() == 0: continue
        for k, nm in enumerate(names):
            v = L1p[k, m]; ok = np.isfinite(v)
            dr = np.nanmean(L1d[:, k][:, m], 1); dvr = np.nanmedian(dvd[:, k][:, m], 1)
            pg.append(dict(c=c, income=gname, n=int(ok.sum()), perturbation=nm, mean_shift=float(np.nanmean(v)), shift_lo=float(np.nanpercentile(dr, 5)),
                           shift_hi=float(np.nanpercentile(dr, 95)), median_dvar=float(np.nanmedian(dvp[k, m])), dvar_lo=float(np.nanpercentile(dvr, 5)), dvar_hi=float(np.nanpercentile(dvr, 95))))
    for sgn, m in [("delta<0", u[:, 1] < 0), ("delta>=0", u[:, 1] >= 0), ("delta identified", rat_d[:, 1] <= 0.8)]:
        k = names.index("half_delta")
        if m.sum() == 0: continue
        dr = np.nanmean(L1d[:, k][:, m], 1)
        pdl.append(dict(c=c, group=sgn, n=int(m.sum()), mean_shift_half_delta=float(np.nanmean(L1p[k, m])), lo=float(np.nanpercentile(dr, 5)), hi=float(np.nanpercentile(dr, 95)),
                        median_dvar=float(np.nanmedian(dvp[k, m]))))
    for k, nm in enumerate(names):
        dr = np.nanmean(L1d[:, k], 1); dv = np.nanmedian(dvd[:, k], 1)
        pg.append(dict(c=c, income="All", n=int(np.isfinite(L1p[k]).sum()), perturbation=nm, mean_shift=float(np.nanmean(L1p[k])), shift_lo=float(np.nanpercentile(dr, 5)),
                       shift_hi=float(np.nanpercentile(dr, 95)), median_dvar=float(np.nanmedian(dvp[k])), dvar_lo=float(np.nanpercentile(dv, 5)), dvar_hi=float(np.nanpercentile(dv, 95))))
for nm, rows in [("params_importer", pi_rows), ("params_commodity", pc_rows), ("identification", id_rows), ("h2_importer", h2i), ("h2_group", h2g),
                 ("h2_reps", h2r), ("perception_groups", pg), ("perception_delta", pdl)]:
    pd.DataFrame(rows).to_csv(f"{out}/{nm}.csv", index=False)
print(pd.DataFrame(id_rows).round(3).to_string()); print(pd.DataFrame(h2g).round(3).to_string())
