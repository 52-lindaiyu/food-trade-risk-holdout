"""Data-coverage statistics requested in review. python code/coverage_stats.py -> results/v2/coverage_*.csv, gdhy_agreement.csv
(i) share of importer-supplier quantity taken from partner (mirror) reports; (ii) importer-years excluded by the
positive-imports rule; (iii) unit-value imputation counts; (iv) GDHY-FAOSTAT anomaly agreement with overlap years."""
import os, json, numpy as np, pandas as pd
CODE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(CODE); os.chdir(ROOT)
exec(open(os.path.join(CODE, "02_build_panel.py")).read()); exec(open(os.path.join(CODE, "03_risk_landscape.py")).read())
src = open(os.path.join(CODE, "models.py")).read()
exec(src.split("def kl_loss")[0].replace("import numpy as np, torch, torch.nn as nn, torch.nn.functional as Fnn", "import numpy as np").replace("torch.set_default_dtype(torch.float64)", ""))
sets = json.load(open("data/sets.json")); out = "results/v2"; os.makedirs(out, exist_ok=True)
tr = pd.concat([pd.read_csv(f"data/{f}", dtype={"rep_m49": str, "par_m49": str}) for f in ["trade_pre2014.csv.gz", "trade_post2013.csv.gz"]])
tr = tr[tr.item.isin(COMMOD)].copy(); tr["c"] = tr.item.map(COMMOD)
tr["rep"] = tr.rep_m49.str.zfill(3).map(M49_ISO); tr["par"] = tr.par_m49.str.zfill(3).map(M49_ISO)
tr = tr.dropna(subset=["rep", "par"]); tr = tr[tr.rep != tr.par]
el = {5610: "imp_q", 5910: "exp_q"}; tr = tr[tr.element.isin(el)]; tr["el"] = tr.element.map(el)
w = tr.pivot_table(index=["c", "rep", "par", "year"], columns="el", values="value", aggfunc="sum").reset_index()
imp = w[["c", "rep", "par", "year", "imp_q"]].rename(columns={"rep": "i", "par": "j"}); exp = w[["c", "rep", "par", "year", "exp_q"]].rename(columns={"rep": "j", "par": "i"})
f = imp.merge(exp, on=["c", "i", "j", "year"], how="outer")
f["mirror"] = ~(f.imp_q.notna() & (f.imp_q > 0)); f["q"] = f.imp_q.where(~f.mirror, f.exp_q); f = f[f.q > 0]
rows = []
for c in sets:
    g = f[(f.c == c) & f.i.isin(sets[c]["I"])]
    for per, (a, b) in {"1988-2013": (1988, 2013), "2014-2024": (2014, 2024)}.items():
        h = g[(g.year >= a) & (g.year <= b)]
        rows.append(dict(c=c, period=per, mirror_quantity_share=float(h[h.mirror].q.sum() / h.q.sum()), mirror_flow_share=float(h.mirror.mean())))
pd.DataFrame(rows).to_csv(f"{out}/coverage_mirror.csv", index=False)
ex, uvr = [], []
for c in sets:
    P = Panel(f"data/arrays/arrays_{c}_full.npz", cutoff=2013)
    for t in range(2014, 2025):
        b = P.yi[t]; b1 = P.yi[t - 1]
        ex.append(dict(c=c, t=t, importers=P.N, eligible=int((P.valid[:, b] & P.valid[:, b1]).sum()), zero_t=int((~P.valid[:, b]).sum()),
                       zero_t1_only=int((P.valid[:, b] & ~P.valid[:, b1]).sum())))
    yrs = np.array(P.years)
    uvr.append(dict(c=c, cells_le2013=int(P.uv_missing[:, yrs <= 2013].sum()), cells_2014_2024=int(P.uv_missing[:, yrs > 2013].sum()),
                    total_cells=int(P.uv_missing.size), sig_scale_le2013=P.sig_scale,
                    sig_scale_allyears=float(np.median(np.array([np.diag(P.SIG[k]) for k in range(len(yrs))])))))
pd.DataFrame(ex).to_csv(f"{out}/coverage_exclusions.csv", index=False); pd.DataFrame(uvr).to_csv(f"{out}/coverage_unitvalues.csv", index=False)
# GDHY agreement
g = pd.read_csv("data/raw2/gdhy_country.csv"); q = pd.read_csv("data/production_qcl.csv.gz", dtype={"m49": str})
q["iso"] = q.m49.str.zfill(3).map(M49_ISO); q["c"] = q.item.map({15: "wheat", 56: "maize", 27: "rice", 236: "soybeans"})
Y = q[q.element == "Yield"].dropna(subset=["iso"]).pivot_table(index=["c", "iso"], columns="year", values="value", aggfunc="sum")
gc = {"wheat": "wheat", "maize": "maize", "rice": "rice", "soybeans": "soybean"}; yrs = list(range(1981, 2017)); rows = []
for c in sets:
    for s in sets[c]["S"]:
        if (c, s) not in Y.index: continue
        gg = g[(g.crop == gc[c]) & (g.iso == s)].set_index("year")["yield"].reindex(yrs)
        if gg.notna().sum() < 25: continue
        yf = Y.loc[(c, s)].reindex(yrs).values.astype(float)
        af, _ = realtime_anomalies(np.log(np.where(yf > 0, yf, np.nan)), yrs); ag, _ = realtime_anomalies(np.log(np.where(gg.values > 0, gg.values, np.nan)), yrs)
        ok = np.isfinite(af) & np.isfinite(ag)
        if ok.sum() >= 15:
            yy = np.array(yrs)[ok]
            rows.append(dict(c=c, iso=s, n_years=int(ok.sum()), first=int(yy.min()), last=int(yy.max()), r=float(np.corrcoef(af[ok], ag[ok])[0, 1])))
pd.DataFrame(rows).to_csv(f"{out}/gdhy_agreement.csv", index=False)
print(pd.DataFrame(rows).groupby("c").agg(n=("r", "size"), med=("r", "median"), first=("first", "min"), last=("last", "max"), nmin=("n_years", "min"), nmax=("n_years", "max")))
