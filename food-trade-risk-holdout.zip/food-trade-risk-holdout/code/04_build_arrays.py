"""Build model arrays for every specification used in the revised analysis.

python code/04_build_arrays.py            -> data/arrays/arrays_<commodity>_<spec>.npz
Specifications (name: trade tag, static cut-off year, policy coding, policy variance, centred):
  dev        pre  2005 base   0.04 no   development fits (train 1988-2005, validate 2006-2013)
  pre/full   pre|full 2013 base 0.04 no  primary specification (identical to the sealed v1 arrays)
  s01,s09    policy-loss variance 0.01 / 0.09 (10% / 30% loss)
  cent       centred Bernoulli policy variance 0.04*pi*(1-pi)
  sevdur     severity x duration weighted restriction intensity
  legal      Ukraine 2022 blockade removed from the restriction coding
Static quantities (re-export hub classification, rest-of-world anomaly weights, rest-of-world distance)
use only years <= the static cut-off. 'pre' arrays contain no trade quantities after 2013.
"""
import os, sys, json, numpy as np, pandas as pd
CODE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(CODE)
D = lambda *p: os.path.join(ROOT, "data", *p)
exec(open(os.path.join(CODE, "02_build_panel.py")).read())
exec(open(os.path.join(CODE, "03_risk_landscape.py")).read())
YEARS = list(range(1986, 2025)); ALLY = list(range(1961, 2025))
CEPII_FIX = {"ROU": "ROM", "COD": "ZAR", "SRB": "YUG", "MNE": "YUG", "TLS": "TMP", "PSE": "PAL"}
TELE_COLS = ["N34_DJF", "N34_JAS", "DMI_SON", "DMI_SON_lag", "NAO_DJFM"]
SPECS = {"dev": ("pre", 2005, "base", 0.04, False), "pre": ("pre", 2013, "base", 0.04, False),
         "full": ("full", 2013, "base", 0.04, False)}
for v, args in {"s01": ("base", 0.01, False), "s09": ("base", 0.09, False), "cent": ("base", 0.04, True),
                "sevdur": ("sevdur", 0.04, False), "legal": ("legal", 0.04, False)}.items():
    SPECS[v + "_pre"] = ("pre",) + (2013,) + args; SPECS[v + "_full"] = ("full",) + (2013,) + args


def load_exog():
    q = pd.read_csv(D("production_qcl.csv.gz"), dtype={"m49": str})
    q["iso"] = q.m49.str.zfill(3).map(M49_ISO)
    q["c"] = q.item.map({15: "wheat", 56: "maize", 27: "rice", 236: "soybeans"})
    q = q.dropna(subset=["iso"])
    Y = q[q.element == "Yield"].pivot_table(index=["c", "iso"], columns="year", values="value", aggfunc="sum").reindex(columns=ALLY)
    Pq = q[q.element == "Production"].pivot_table(index=["c", "iso"], columns="year", values="value", aggfunc="sum").reindex(columns=ALLY)
    for c in ["wheat", "maize", "rice", "soybeans"]:
        for s in ["UKR", "KAZ"]:
            if (c, s) in Y.index and (c, "RUS") in Y.index:
                Y.loc[(c, s), list(range(1961, 1992))] = Y.loc[(c, "RUS"), list(range(1961, 1992))].values
    tele = pd.read_csv(D("raw2", "teleconnections_annual.csv"), index_col=0).reindex(ALLY)
    dist = pd.read_excel(D("raw2", "dist_cepii.xls"))
    for col in ["dist", "distw", "contig", "comlang_off"]: dist[col] = pd.to_numeric(dist[col], errors="coerce")
    wb = json.load(open(D("raw2", "wb_countries.json")))[1]
    wbm = {d["id"]: (d["region"]["value"].strip(), d["incomeLevel"]["value"].strip()) for d in wb}
    wbm["TWN"] = ("East Asia & Pacific", "High income")
    return Y, Pq, tele, dist, wbm


def anomalies_for(Y, c):
    out_a, out_z = {}, {}
    for iso in Y.loc[c].index:
        yv = Y.loc[(c, iso)].values.astype(float); ly = np.log(np.where(yv > 0, yv, np.nan))
        a, z = realtime_anomalies(ly, ALLY); out_a[iso] = a; out_z[iso] = z
    return pd.DataFrame(out_a, index=ALLY).T, pd.DataFrame(out_z, index=ALLY).T


def assemble(flows, sets, spec, exog, ANZ):
    tag, cut, polv, s2p, cent = SPECS[spec]
    Y, Pq, tele, dist, wbm = exog
    pol = pd.read_csv(D("derived", f"policy_annual_{polv}.csv"))
    meta = {}
    for c in ["wheat", "maize", "rice", "soybeans"]:
        S = sets[c]["S"]; I = sets[c]["I"]; K = len(S) + 1
        tab = shares(flows, sets, c)
        Q = np.full((len(I), len(YEARS), K), np.nan)
        for a, i in enumerate(I):
            for b, t in enumerate(YEARS):
                if (i, t) in tab.index: Q[a, b] = tab.loc[(i, t)].values
                elif t <= flows.year.max(): Q[a, b] = 0.0
        uv, tot = unit_values(flows, sets, c)
        UV = uv.reindex(YEARS).T.values; TOT = tot.reindex(YEARS).T.values
        an, zz = ANZ[c]
        Pc = Pq.loc[c]
        pre_mean = Pc[list(range(1986, cut + 1))].mean(1)
        exp_mean = tot.loc[1986:cut].mean()
        hub = [s for s in S if (s not in pre_mean.index) or (np.nan_to_num(pre_mean.get(s, 0)) < 0.5 * exp_mean.get(s, 0))]
        others = [x for x in an.index if x not in S and x in pre_mean.index and pre_mean[x] > 0]
        wts = pre_mean[others]
        def wavg(df):
            v = df.loc[others].values; m = np.isfinite(v); w = wts.values[:, None] * m
            return np.where(w.sum(0) > 0, np.nansum(np.where(m, v, 0) * wts.values[:, None], 0) / np.maximum(w.sum(0), 1e-12), np.nan)
        rowa = wavg(an); rowz = wavg(zz)
        A = np.vstack([an.loc[s].values if (s in an.index and s not in hub) else rowa for s in S] + [rowa])
        Z = np.vstack([zz.loc[s].values if (s in zz.index and s not in hub) else rowz for s in S] + [rowz])
        POL = np.zeros((K, len(ALLY)))
        for _, r in pol[pol.commodity == c].iterrows():
            if r.iso3 in S: POL[S.index(r.iso3), ALLY.index(r.year)] = r.value
        T5 = tele[TELE_COLS].values
        SIG = np.full((len(YEARS), K, K), np.nan)
        for b, t in enumerate(YEARS):
            SIG[b], _ = sigma_t(A, T5, POL, ALLY, t, sigma2_pol=s2p, centered=cent)
        dd = dist.set_index(["iso_o", "iso_d"]); fx = lambda x: CEPII_FIX.get(x, x)
        Dm = np.full((len(I), K), np.nan); CT = np.zeros((len(I), K)); CL = np.zeros((len(I), K))
        for a, i in enumerate(I):
            for k, s in enumerate(S):
                key = (fx(s), fx(i))
                if key in dd.index:
                    r = dd.loc[key]; r = r.iloc[0] if isinstance(r, pd.DataFrame) else r
                    Dm[a, k] = r.distw if np.isfinite(r.distw) else r.dist; CT[a, k] = r.contig; CL[a, k] = r.comlang_off
        g = flows[(flows.c == c) & (flows.year <= cut) & ~flows.j.isin(S)]
        for a, i in enumerate(I):
            gi = g[g.i == i]; ds = []; ws = []
            for j, qq in gi.groupby("j").q.sum().items():
                key = (fx(j), fx(i))
                if key in dd.index:
                    r = dd.loc[key]; r = r.iloc[0] if isinstance(r, pd.DataFrame) else r; ds.append(r.distw if np.isfinite(r.distw) else r.dist); ws.append(qq)
            Dm[a, K - 1] = np.average(ds, weights=ws) if ds else np.nan
        Dm = np.where(np.isfinite(Dm), Dm, np.nanmedian(Dm))
        reg = [wbm.get(i, ("NA", "NA"))[0] for i in I]; inc = [wbm.get(i, ("NA", "NA"))[1] for i in I]
        os.makedirs(D("arrays"), exist_ok=True)
        np.savez_compressed(D("arrays", f"arrays_{c}_{spec}.npz"), I=np.array(I), S=np.array(S + ["ROW"]), years=np.array(YEARS),
                            ally=np.array(ALLY), Q=Q, UV=UV, TOT=TOT, A=A, Z=Z, POL=POL, SIG=SIG, D=Dm, CT=CT, CL=CL,
                            reg=np.array(reg), inc=np.array(inc), hub=np.array(hub), static_cutoff=np.array(cut))
        meta[c] = dict(hub=hub, n_rowdist_missing=int(sum(1 for a in range(len(I)) if not np.isfinite(Dm[a, K - 1]))))
    return meta


if __name__ == "__main__":
    specs = sys.argv[1:] or list(SPECS)
    tr_pre = pd.read_csv(D("trade_pre2014.csv.gz"), dtype={"rep_m49": str, "par_m49": str})
    fl = {"pre": build_flows(tr_pre)}
    if any(SPECS[s][0] == "full" for s in specs):
        tr_post = pd.read_csv(D("trade_post2013.csv.gz"), dtype={"rep_m49": str, "par_m49": str})
        fl["full"] = build_flows(pd.concat([tr_pre, tr_post]))
    sets = json.load(open(D("sets.json")))
    exog = load_exog(); ANZ = {c: anomalies_for(exog[0], c) for c in ["wheat", "maize", "rice", "soybeans"]}
    for s in specs:
        m = assemble(fl[SPECS[s][0]], sets, s, exog, ANZ); print(s, json.dumps({c: v["hub"] for c, v in m.items()}), flush=True)
