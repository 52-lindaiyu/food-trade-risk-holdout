"""Thin computation-only entry point; original scientific scripts are unchanged."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STAGES = ['policy', 'arrays', 'gate', 'dev', 'select', 'fit', 'freeze', 'post', 'evaluate', 'analyse']


def strict_inputs():
    entries = []
    for key in ['analysis_plan_v1', 'amendment_A']:
        rec = json.loads((ROOT/f'prereg/{key}.sha256.json').read_text())
        digest = rec.get('sha256', next(iter(rec.values()))) if isinstance(rec, dict) else rec
        entries.append((f'prereg/{key}.md', digest))
    manifest = json.loads((ROOT/'data/MANIFEST_inputs.json').read_text())
    entries += [(f'data/arrays/{n}', h) for n,h in manifest['arrays'].items()]
    frozen = json.loads((ROOT/'prereg/frozen_param_hashes.json').read_text())
    entries += [(f'data/v1_frozen/{n}', h) for n,h in frozen.items()]
    for name, digest in entries:
        p = ROOT/name
        if not p.is_file(): raise SystemExit(f'Missing required input: {name}')
        if hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            raise SystemExit(f'Input hash mismatch: {name}')
    print(f'Strict input checks: {len(entries)} files match; all present.', flush=True)


def strict_fits():
    p = ROOT/'out/fit_param_sha256.json'
    if not p.is_file(): raise SystemExit('No fitted-parameter manifest; run fit then freeze.')
    expected = json.loads(p.read_text())
    if len(expected) != 172: raise SystemExit(f'Incomplete fit set: {len(expected)}/172 files. Check the fitting logs.')
    for name, digest in expected.items():
        f = ROOT/'out/fit'/name
        if not f.is_file(): raise SystemExit(f'Missing fitted parameter: {name}')
        if hashlib.sha256(f.read_bytes()).hexdigest() != digest:
            raise SystemExit(f'Fitted parameter hash mismatch: {name}')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--from', dest='start', choices=STAGES, default='gate')
    ap.add_argument('--to', dest='stop', choices=STAGES, default='gate')
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()
    if args.workers < 1: ap.error('--workers must be positive')
    first, last = STAGES.index(args.start), STAGES.index(args.stop)
    if first > last: ap.error('--from must not follow --to')
    py, workers = sys.executable, str(args.workers)
    commands = {
        'policy': [[py,'code/00_expand_policy.py']],
        'arrays': [[py,'code/04_build_arrays.py']],
        'gate': [[py,'code/hashgate.py','check']],
        'dev': [[py,'code/run.py','dev',workers]],
        'select': [[py,'code/run.py','select']],
        'fit': [[py,'code/run.py','fit',workers]],
        'freeze': [[py,'code/hashgate.py','freeze']],
        'post': [[py,'code/hashgate.py','verify-fits'],[py,'code/run.py','post',workers]],
        'evaluate': [[py,'code/evaluate_v2.py','v2']],
        'analyse': [[py,'code/analyse_identification.py'],[py,'code/coverage_stats.py']],
    }
    for stage in STAGES[first:last+1]:
        if not args.dry_run and stage in {'gate','dev','fit','post'}: strict_inputs()
        if not args.dry_run and stage == 'post': strict_fits()
        for cmd in commands[stage]:
            print(f'[{stage}] ' + ' '.join(cmd), flush=True)
            if not args.dry_run: subprocess.run(cmd,cwd=ROOT,check=True)
        if not args.dry_run and stage == 'freeze': strict_fits()
    if args.dry_run: print('Plan only; no scientific computation performed.')


if __name__ == '__main__': main()
