# Verification performed on 2026-10-26

- Original scientific code, parameters and seeds were copied without edits.
- All 52 canonical array hashes and 36 sealed-v1 parameter hashes match; sealed protocol and amendment hashes match.
- The default reproduction entry point completed input verification, including presence checks that the original hash gate lacks.
- All 15 exported scientific scripts and the new entry point passed Python syntax checks; imported external packages are available locally.
- The original v2 model module loaded all four primary BR state files in the complete local workspace.
- A lightweight, read-only check recalculated 3,830 v2 case losses for nine model families from supplied local forecasts. Maximum absolute discrepancy was 1.78e-15. Those forecasts/results are not shipped in this computation-only repository.
- The same local check on v1 found a Persistence discrepancy of up to 0.0014966294962057702 nats; the other five compared v1 losses agree to numerical precision. This discrepancy was documented without modifying scientific code or stored results. The repository's public entry point evaluates v2 only.
- The source workspace holds 8 of the 172 v2 fitted files listed in its manifest. None of these v2 fitted files or forecasts are included here; full fitting is required before postprocessing in a fresh checkout.
- Local smoke environment: Python 3.13, NumPy 2.2.6, pandas 3.0.5, SciPy 1.17.1, PyTorch 2.13.0+cpu. This differs from the original pinned fitting environment.
- No full fitting, solver sweep, bootstrap-interval regeneration, raw bulk download, software installation or publication was performed. File and smoke checks are not full experimental reproduction.
