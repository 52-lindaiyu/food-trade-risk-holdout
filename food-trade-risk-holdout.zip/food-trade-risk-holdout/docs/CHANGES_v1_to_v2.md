# Changes from the sealed analysis (v1) to the corrected analysis (v2)

| Area | v1 (sealed, `code/v1_*.py`) | v2 (`code/models.py`, `code/run.py`) |
|---|---|---|
| Covariance scale | median supplier variance over all 39 stored years (1986-2024) | median over forecast years <= cut-off (2005 dev, 2013 final); stored in `prep` of each fit |
| Unit-value imputation | supplier median over 1986-2013 for dev and final | median over years <= cut-off |
| Static array quantities (hubs, ROW weights, ROW distance) | 1986-2013 for dev and final | 1986-cut-off (`04_build_arrays.py`, spec `dev` uses 2005) |
| Fixed-point solver | 60 damped mirror-descent steps, backprop through iterations, `last_resid` = change of damped iterates | damped Newton to max abs logit residual < 1e-11, implicit-function gradients, undamped residual, Frank-Wolfe gap and SLSQP audit |
| Memory | (1-phi) phi^l, unnormalised, truncated at 50 lags | phi^l normalised over available lags, L = 30 |
| kappa prior | text said log kappa ~ N(0,4); code softplus(l_kappa), l_kappa ~ N(0,4) | code unchanged (softplus), text corrected; same for log eta ~ N(0, 2^2) |
| Unavailable supplier utility | -1e9 | -60 (weight ~1e-26) |
| BR0 tuning | inherited BR settings | tuned separately by the registered rule |
| Laplace | importer 4x4 blocks with nuisance fixed, negative variances clipped | full Hessian (FD of exact gradients + exact prior Hessian), marginal and conditional SDs, eigenvalue diagnostics |
| H2 | signed group bias averaged across groups and reps + importer-level coverage | group-level absolute bias + group-mean coverage (marginal), MC SE; importer-level reported separately |
| GNN without risk inputs | inputs zeroed in the full architecture | own input dimension, own hyper-parameter selection |
| Added competitors/variants | -- | GRAVeq, GNNfull, GNNnet, single seeds, h = 2 models, 10 BR specification variants |
| Evaluation | importer-commodity bootstrap | + country, country x year (pigeonhole), LOWO, annual, TOST, floor sensitivity (available-only), decomposition, volume weights |
| Table 1 | H1(b) printed with reversed sign | single sign convention A = L(comp) - L(BR) |
